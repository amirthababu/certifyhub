// Random Forest ML Growth Analysis Service
// Changes:
//   - uniqueCategories: counted from certificate TITLE (domain extraction), not NLP category
//   - monthsActive: sum of actual course/internship durations; hackathon = 1 month each
//   - growthRate (certs/month): REMOVED from features returned to frontend

const MS_DAY   = 1000 * 60 * 60 * 24;
const MS_MONTH = MS_DAY * 30.44;

// ── Domain keyword map — extracted from TITLE ──────────────────────────────────
// Each entry: domain name → keywords that appear in a certificate title
const DOMAIN_KEYWORDS = {
  'Java':            ['java', 'spring boot', 'spring', 'hibernate', 'maven'],
  'Python':          ['python', 'django', 'flask', 'fastapi', 'pandas', 'numpy', 'scipy'],
  'JavaScript':      ['javascript', 'js ', 'node.js', 'nodejs', 'express', 'npm'],
  'TypeScript':      ['typescript', 'ts '],
  'React':           ['react', 'reactjs', 'react.js', 'next.js', 'nextjs'],
  'Angular':         ['angular', 'angularjs'],
  'Vue':             ['vue', 'vuejs', 'vue.js', 'nuxt'],
  'HTML/CSS':        ['html', 'css', 'sass', 'scss', 'bootstrap', 'tailwind', 'frontend design'],
  'C/C++':           ['c++', 'cpp', ' c ', 'c programming', 'stl'],
  'C#/.NET':         ['c#', 'csharp', '.net', 'asp.net', 'dotnet'],
  'Go':              ['golang', ' go ', 'go programming'],
  'Rust':            ['rust programming', 'rust lang'],
  'PHP':             ['php', 'laravel', 'symfony', 'codeigniter'],
  'Ruby':            ['ruby', 'rails', 'ruby on rails'],
  'Swift/iOS':       ['swift', 'ios', 'xcode', 'iphone'],
  'Kotlin/Android':  ['kotlin', 'android', 'android studio'],
  'Flutter':         ['flutter', 'dart'],
  'React Native':    ['react native'],
  'SQL':             ['sql', 'mysql', 'postgresql', 'postgres', 'sqlite', 'oracle sql', 'mariadb'],
  'MongoDB':         ['mongodb', 'mongoose', 'nosql', 'mongo'],
  'Redis':           ['redis', 'caching', 'memcache'],
  'Machine Learning':['machine learning', ' ml ', 'scikit', 'sklearn'],
  'Deep Learning':   ['deep learning', 'neural network', 'cnn', 'rnn', 'lstm', 'transformer'],
  'Data Science':    ['data science', 'data analysis', 'data analytics', 'pandas', 'matplotlib'],
  'AI':              ['artificial intelligence', ' ai ', 'generative ai', 'prompt engineering', 'llm'],
  'NLP':             ['nlp', 'natural language', 'text mining'],
  'Computer Vision': ['computer vision', 'image processing', 'opencv'],
  'AWS':             ['aws', 'amazon web services', 's3', 'ec2', 'lambda'],
  'Azure':           ['azure', 'microsoft azure'],
  'GCP':             ['gcp', 'google cloud', 'google cloud platform'],
  'Docker':          ['docker', 'containerization', 'container'],
  'Kubernetes':      ['kubernetes', 'k8s', 'helm'],
  'DevOps':          ['devops', 'ci/cd', 'jenkins', 'github actions', 'gitlab ci', 'terraform', 'ansible'],
  'Linux':           ['linux', 'unix', 'bash', 'shell scripting', 'ubuntu'],
  'Networking':      ['networking', 'ccna', 'tcp/ip', 'cisco', 'network'],
  'Cybersecurity':   ['cybersecurity', 'cyber security', 'ethical hacking', 'penetration testing', 'security+'],
  'Blockchain':      ['blockchain', 'web3', 'solidity', 'ethereum', 'smart contract'],
  'Data Structures': ['data structure', 'algorithms', 'dsa', 'competitive programming', 'leetcode'],
  'System Design':   ['system design', 'software architecture', 'design pattern'],
  'Agile/Scrum':     ['agile', 'scrum', 'kanban', 'jira', 'project management'],
  'UI/UX':           ['ui/ux', 'ui ux', 'figma', 'user experience', 'user interface design'],
  'Testing/QA':      ['testing', 'selenium', 'jest', 'quality assurance', ' qa '],
  'R':               [' r programming', 'rstudio', 'tidyverse'],
  'MATLAB':          ['matlab'],
  'Excel/Power BI':  ['excel', 'power bi', 'powerbi', 'tableau', 'data visualization'],
};

/**
 * Extract distinct technology domains from a certificate title.
 * Returns array of matched domain names.
 */
function extractDomainsFromTitle(title) {
  const lower = (title || '').toLowerCase();
  const matched = [];
  for (const [domain, keywords] of Object.entries(DOMAIN_KEYWORDS)) {
    if (keywords.some(kw => lower.includes(kw))) {
      matched.push(domain);
    }
  }
  return matched;
}

/**
 * Count UNIQUE domains across all certificate titles.
 * Returns: { domains: ['Java','Python',...], count: N }
 */
function countUniqueDomains(certificates) {
  const allDomains = new Set();
  certificates.forEach(cert => {
    const domains = extractDomainsFromTitle(cert.title);
    domains.forEach(d => allDomains.add(d));
  });
  return { domains: [...allDomains], count: allDomains.size };
}

// ── Duration helpers ──────────────────────────────────────────────────────────

/**
 * Detect if a certificate is a hackathon / participation (no real duration).
 * These get 1 month added to monthsActive.
 */
function isHackathonOrParticipation(cert) {
  const lower = ((cert.title || '') + ' ' + (cert.description || '') + ' ' + (cert.certificateType || '')).toLowerCase();
  return (
    lower.includes('hackathon') ||
    lower.includes('participation') ||
    lower.includes('participated') ||
    lower.includes('workshop') ||
    lower.includes('seminar') ||
    lower.includes('symposium') ||
    lower.includes('conference') ||
    cert.certificateType === 'other'
  );
}

/**
 * Compute total "months active" by summing each certificate's real duration.
 *   - Course:      courseStartDate → courseEndDate
 *   - Internship:  internshipStartDate → internshipEndDate
 *   - Hackathon / participation / "other" with no dates: contributes 1 month
 *   - Any cert with no start/end dates: contributes 1 month (minimum)
 */
function computeTotalMonthsActive(certificates) {
  let total = 0;

  certificates.forEach(cert => {
    const start = cert.courseStartDate || cert.internshipStartDate;
    const end   = cert.courseEndDate   || cert.internshipEndDate;

    if (start && end) {
      const months = Math.max(0.25, (new Date(end) - new Date(start)) / MS_MONTH);
      total += months;
    } else {
      // No dates provided — hackathon, participation, or bare certificate → 1 month
      total += 1;
    }
  });

  return Math.max(1, total);
}

// ── Recommendation suggestions ────────────────────────────────────────────────
const COURSE_SUGGESTIONS = {
  Programming: ['Advanced Algorithms & Data Structures','Design Patterns in Python/Java','Clean Code Principles','Competitive Programming'],
  Backend:     ['Microservices Architecture','REST API Best Practices','Node.js / Spring Boot Advanced','GraphQL Essentials'],
  Frontend:    ['React Advanced Patterns','Performance Optimization & Web Vitals','TypeScript Mastery','CSS Architecture'],
  Database:    ['SQL Query Optimization','NoSQL vs SQL Trade-offs','Database Indexing & Tuning','MongoDB for Developers'],
  Cloud:       ['AWS Certified Cloud Practitioner','Docker & Kubernetes','Terraform / IaC','Serverless Architecture'],
  'AI/ML':     ['Machine Learning with Python','Deep Learning Basics with TensorFlow','MLOps & Model Deployment','NLP Fundamentals'],
  Mobile:      ['Cross-Platform with Flutter','React Native Advanced','iOS/Android Security','Mobile UI/UX Design'],
  Other:       ['System Design Fundamentals','Software Architecture Patterns','Agile & Scrum','Technical Communication'],
};

// ── Feature extraction ────────────────────────────────────────────────────────
function extractFeatures(certificates, areasOfInterest = []) {
  if (!certificates || certificates.length === 0) return null;

  const sorted = [...certificates].sort((a, b) => new Date(a.issueDate) - new Date(b.issueDate));

  // NLP-based category counts (used internally for career prediction + recommendations)
  const categoryCounts = { Programming:0, Backend:0, Frontend:0, Database:0, Cloud:0, 'AI/ML':0, Mobile:0, Other:0 };
  const keywordMap = {}, issuers = {};

  certificates.forEach(cert => {
    if (categoryCounts.hasOwnProperty(cert.category)) categoryCounts[cert.category]++;
    if (cert.keywords) cert.keywords.forEach(k => { keywordMap[k] = (keywordMap[k] || 0) + 1; });
    if (cert.issuer)   issuers[cert.issuer] = (issuers[cert.issuer] || 0) + 1;
  });

  // ── Unique Categories: count distinct domains extracted from TITLES ──────────
  const { domains: uniqueDomainList, count: uniqueDomainCount } = countUniqueDomains(certificates);

  // ── Months Active: sum of actual durations ──────────────────────────────────
  const monthsActive = computeTotalMonthsActive(certificates);

  // Still compute growthRate internally (used in decision trees + recommendations)
  // but it will NOT be exposed to the frontend
  const growthRate = certificates.length / monthsActive;

  // avgTimeGap — used in consistency decision tree
  const timeGaps = [];
  for (let i = 1; i < sorted.length; i++) {
    timeGaps.push((new Date(sorted[i].issueDate) - new Date(sorted[i - 1].issueDate)) / MS_DAY);
  }
  const avgTimeGap = timeGaps.length ? timeGaps.reduce((a, b) => a + b, 0) / timeGaps.length : 0;

  // uniqueCategories for decision trees = NLP category count (unchanged)
  const uniqueCategories = Object.values(categoryCounts).filter(c => c > 0).length;

  const skillLevels = { Beginner: 0, Intermediate: 0, Advanced: 0 };
  certificates.forEach(c => { if (skillLevels.hasOwnProperty(c.skillLevel)) skillLevels[c.skillLevel]++; });
  const progressionScore = (skillLevels.Advanced * 3 + skillLevels.Intermediate * 2 + skillLevels.Beginner) / certificates.length;

  const topKeywords      = Object.entries(keywordMap).sort((a, b) => b[1] - a[1]).slice(0, 10).map(([k]) => k);
  const [topCategory, topCategoryCount] = Object.entries(categoryCounts).sort((a, b) => b[1] - a[1])[0];

  return {
    totalCount: certificates.length,
    categoryCounts,
    avgTimeGap,
    growthRate,
    monthsActive,
    uniqueCategories,           // NLP-based (for decision trees)
    uniqueDomainCount,          // Title-based domain count (shown in UI)
    uniqueDomainList,           // Actual domain names (shown in UI)
    diversityScore: uniqueCategories / 8,
    progressionScore,
    skillLevels,
    topKeywords,
    topCategory,
    topCategoryCount,
    issuers,
    areasOfInterest: Array.isArray(areasOfInterest) ? areasOfInterest : []
  };
}

// ── Decision Trees (unchanged — still use NLP category counts internally) ─────
function decisionTree1_VolumeScore(f) {
  const c = f.totalCount;
  return c >= 20 ? 25 : c >= 15 ? 20 : c >= 10 ? 15 : c >= 5 ? 10 : 5;
}
function decisionTree2_DiversityScore(f) {
  const u = f.uniqueCategories;
  return u >= 6 ? 20 : u >= 5 ? 16 : u >= 4 ? 12 : u >= 3 ? 8 : u >= 2 ? 5 : 2;
}
function decisionTree3_ProgressionScore(f) {
  const p = f.progressionScore, a = f.skillLevels.Advanced;
  return p >= 2.5 && a >= 3 ? 25 : p >= 2.0 ? 20 : p >= 1.5 ? 15 : p >= 1.2 ? 10 : 5;
}
function decisionTree4_ConsistencyScore(f) {
  const g = f.growthRate, t = f.avgTimeGap;
  return g >= 2 && t < 45 ? 15 : g >= 1.5 ? 12 : g >= 1 ? 9 : g >= 0.5 ? 6 : 3;
}
function decisionTree5_SpecializationScore(f) {
  const m = Math.max(...Object.values(f.categoryCounts));
  return m >= 5 && f.uniqueCategories >= 3 ? 15 : m >= 5 ? 12 : m >= 3 ? 9 : m >= 2 ? 6 : 3;
}

function calculateCareerReadiness(features) {
  const t1 = decisionTree1_VolumeScore(features),
        t2 = decisionTree2_DiversityScore(features),
        t3 = decisionTree3_ProgressionScore(features),
        t4 = decisionTree4_ConsistencyScore(features),
        t5 = decisionTree5_SpecializationScore(features);
  return {
    score: Math.min(100, t1 + t2 + t3 + t4 + t5),
    breakdown: { volume: t1, diversity: t2, progression: t3, consistency: t4, specialization: t5 }
  };
}

function calculateSkillLevel(f) {
  return Math.min(100, Math.round(
    Math.min(30, f.totalCount * 2) +
    Math.min(25, f.uniqueCategories * 4) +
    Math.min(25, f.progressionScore * 10) +
    Math.min(20, f.skillLevels.Advanced * 4)
  ));
}

function predictCareerRole(f) {
  const { categoryCounts: c, totalCount: t, skillLevels: sl } = f;
  const wc = (base, pairs) => Math.round(Math.min(97, base + (pairs.reduce((s, [, v]) => s + v, 0) / t) * 40 + sl.Advanced * 2));
  const roles = [];
  if (c.Backend >= 1 && c.Frontend >= 1) roles.push({ role: 'Full Stack Developer',        confidence: wc(55, [['b', c.Backend], ['f', c.Frontend]]) });
  if (c.Backend >= 1 || c.Database >= 1) roles.push({ role: 'Backend Developer',           confidence: wc(48, [['b', c.Backend], ['db', c.Database]]) });
  if (c.Frontend >= 1)                   roles.push({ role: 'Frontend Developer',           confidence: wc(50, [['f', c.Frontend]]) });
  if (c.Cloud >= 1)                      roles.push({ role: 'Cloud / DevOps Engineer',      confidence: wc(52, [['c', c.Cloud]]) });
  if (c['AI/ML'] >= 1)                   roles.push({ role: 'Data Scientist / ML Engineer', confidence: wc(55, [['ai', c['AI/ML']]]) });
  if (c.Mobile >= 1)                     roles.push({ role: 'Mobile App Developer',         confidence: wc(50, [['m', c.Mobile]]) });
  if (c.Programming >= 1)                roles.push({ role: 'Software Engineer',            confidence: wc(45, [['p', c.Programming]]) });
  if (roles.length === 0) {
    roles.push(t >= 3
      ? { role: 'Emerging Developer', confidence: Math.min(80, 40 + t * 2) }
      : { role: 'Early Learner',      confidence: 25 + t * 5 });
  }
  const seen = new Set();
  const unique = roles.filter(r => { if (seen.has(r.role)) return false; seen.add(r.role); return true; });
  unique.sort((a, b) => b.confidence - a.confidence);
  if (unique[0]?.confidence > 95) unique[0].confidence = 95;
  return unique.slice(0, 5);
}

function generateRecommendations(features) {
  const { categoryCounts: c, totalCount: n, uniqueCategories, skillLevels: sl,
          topCategory, topCategoryCount, areasOfInterest } = features;
  const recs = [];

  // Interest gap analysis
  if (Array.isArray(areasOfInterest) && areasOfInterest.length > 0) {
    areasOfInterest.filter(i => (c[i] || 0) === 0).slice(0, 2).forEach(gap => {
      recs.push({
        skill: `${gap} — Your Interest`, priority: 'High', type: 'interest_gap',
        reason: `You marked "${gap}" as an area of interest but have no certificates in it yet. This is your biggest skill gap!`,
        estimatedTime: '4–6 weeks', suggestions: COURSE_SUGGESTIONS[gap] || [`Introduction to ${gap}`, `${gap} Fundamentals`]
      });
    });
    areasOfInterest.filter(i => (c[i] || 0) > 0).slice(0, 1).forEach(interest => {
      recs.push({
        skill: `Advance in ${interest}`, priority: (c[interest] || 0) >= 3 ? 'High' : 'Medium', type: 'interest_advance',
        reason: `You have ${c[interest]} certificate(s) in "${interest}". Keep advancing to expert level!`,
        estimatedTime: '6–8 weeks', suggestions: (COURSE_SUGGESTIONS[interest] || []).slice(1)
      });
    });
  }

  // Market gaps
  const covered = recs.map(r => r.skill);
  [c.Cloud === 0 && 'Cloud', c.Database === 0 && 'Database', (c['AI/ML'] === 0 && n >= 5) && 'AI/ML']
    .filter(Boolean).filter(m => !covered.some(s => s.includes(m))).slice(0, 1)
    .forEach(mk => {
      recs.push({
        skill: mk === 'AI/ML' ? 'AI/ML Fundamentals' : `${mk} Management`, priority: 'High', type: 'market_gap',
        reason: `No certificates in ${mk} yet — highly valued in the industry.`,
        estimatedTime: '3–5 weeks', suggestions: COURSE_SUGGESTIONS[mk] || [`Introduction to ${mk}`]
      });
    });

  // Deepen top category
  if (topCategoryCount >= 1 && topCategory !== 'Other' && !recs.some(r => r.skill.includes(topCategory))) {
    recs.push({
      skill: `Advanced ${topCategory}`, priority: topCategoryCount >= 3 ? 'High' : 'Medium', type: 'deepen',
      reason: `${topCategoryCount} cert(s) in ${topCategory}. Deepen to accelerate your career.`,
      estimatedTime: '6–8 weeks', suggestions: COURSE_SUGGESTIONS[topCategory] || ['Advanced Topics']
    });
  }

  // Diversify
  if (uniqueCategories < 3 && n >= 4) {
    const have    = Object.entries(c).filter(([, v]) => v > 0).map(([k]) => k);
    const missing = ['Backend', 'Frontend', 'Cloud', 'Database', 'AI/ML', 'Mobile'].filter(x => !have.includes(x));
    if (missing.length) {
      recs.push({
        skill: 'Skill Diversification', priority: 'Medium', type: 'diversify',
        reason: `Certs focus on ${have.join(', ')}. Try ${missing.slice(0, 2).join(' or ')} to become more versatile.`,
        estimatedTime: '2–3 months', suggestions: missing.slice(0, 3).map(x => `Introduction to ${x}`)
      });
    }
  }

  // Level up
  if (sl.Beginner > sl.Intermediate + sl.Advanced && n >= 4) {
    recs.push({
      skill: 'Level Up to Intermediate/Advanced', priority: 'High', type: 'level_up',
      reason: `${sl.Beginner} of ${n} certs are Beginner level. Progress to boost career readiness significantly.`,
      estimatedTime: '4–6 weeks per course',
      suggestions: [`Intermediate ${topCategory} Certification`, 'Project-Based Advanced Course', 'Industry Recognised Certification']
    });
  }

  // Consistency
  if (features.growthRate < 0.5 && n >= 3) {
    recs.push({
      skill: 'Learning Consistency', priority: 'Medium', type: 'consistency',
      reason: `Learning pace is low. More consistent effort compounds faster.`,
      estimatedTime: 'Ongoing',
      suggestions: ['Set a monthly learning goal', 'Join a study group', 'Use structured paths on Coursera/Udemy']
    });
  }

  // Programming basics
  if (c.Programming === 0 && n < 5) {
    recs.push({
      skill: 'Programming Fundamentals', priority: 'High', type: 'foundation',
      reason: 'A strong programming foundation is essential for all tech roles.',
      estimatedTime: '4–6 weeks',
      suggestions: ['Python for Beginners', 'JavaScript Essentials', 'Data Structures & Algorithms']
    });
  }

  return recs.slice(0, 6);
}

function generateGrowthChart(certificates) {
  if (!certificates || certificates.length === 0) return [];
  const sorted = [...certificates].sort((a, b) => new Date(a.issueDate) - new Date(b.issueDate));
  let cum = 0;
  return sorted.map(c => ({ date: new Date(c.issueDate).toISOString().split('T')[0], count: ++cum, category: c.category }));
}

function generatePeerComparison(features) {
  const avg = 8, top = 25, pct = Math.min(99, Math.round((features.totalCount / top) * 100));
  return {
    userCertificates: features.totalCount, departmentAverage: avg, topPerformer: top, percentile: pct,
    ranking: pct >= 75 ? 'Top 25%' : pct >= 50 ? 'Top 50%' : 'Below Average'
  };
}

function performMLAnalysis(certificates, userDepartment, areasOfInterest = []) {
  const features = extractFeatures(certificates, areasOfInterest);
  if (!features) return { error: 'Insufficient data', message: 'Upload at least one certificate to view growth analysis' };

  const careerReadiness = calculateCareerReadiness(features);
  const skillLevel      = calculateSkillLevel(features);
  const careerRoles     = predictCareerRole(features);
  const recommendations = generateRecommendations(features);
  const growthChart     = generateGrowthChart(certificates);
  const peerComparison  = generatePeerComparison(features);

  return {
    skillLevelScore:          skillLevel,
    careerReadinessScore:     careerReadiness.score,
    careerReadinessBreakdown: careerReadiness.breakdown,
    predictedRoles:           careerRoles,
    recommendations,
    growthChart,
    peerComparison,
    features: {
      totalCertificates: features.totalCount,
      categoryCounts:    features.categoryCounts,

      // ── Unique domains extracted from certificate TITLES ──────────────────
      uniqueCategories:  features.uniqueDomainCount,   // count of distinct tech domains
      uniqueDomainList:  features.uniqueDomainList,    // e.g. ['Java','Python','React']

      // ── Months Active: sum of real course/internship/hackathon durations ──
      monthsActive: parseFloat(features.monthsActive.toFixed(1)),

      // growthRate intentionally NOT included here (removed from UI)

      skillLevels:    features.skillLevels,
      topKeywords:    features.topKeywords,
      areasOfInterest: features.areasOfInterest
    }
  };
}

module.exports = {
  performMLAnalysis, extractFeatures, calculateCareerReadiness,
  calculateSkillLevel, predictCareerRole, generateRecommendations,
  countUniqueDomains, computeTotalMonthsActive, extractDomainsFromTitle,
  COURSE_SUGGESTIONS
};
