const express  = require('express');
const router   = express.Router();
const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const User     = require('../models/User');
const { auth } = require('../middleware/auth');

/* ── Register ── */
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, role, rollNumber, department, subject } = req.body;
    if (!name || !email || !password || !role) return res.status(400).json({ error:'Please provide all required fields' });
    if (role !== 'student' && role !== 'teacher')  return res.status(400).json({ error:'Invalid role' });
    if (role === 'student' && (!rollNumber || !department)) return res.status(400).json({ error:'Students must provide roll number and department' });
    if (role === 'teacher' && !subject) return res.status(400).json({ error:'Teachers must provide their department' });

    if (await User.findOne({ email: email.toLowerCase() })) return res.status(400).json({ error:'Email already registered' });

    const hashedPassword = await bcrypt.hash(password, 10);

    // For teachers: `subject` field holds the dept label entered at registration.
    // We also set `department` = subject so the unified dept-matching logic works.
    const user = new User({
      name,
      email: email.toLowerCase(),
      password: hashedPassword,
      role,
      rollNumber:  role === 'student' ? rollNumber  : undefined,
      department:  role === 'student' ? department  : subject, // ← key fix
      subject:     role === 'teacher' ? subject     : undefined,
      areasOfInterest: [],
      isApproved: false
    });

    await user.save();
    res.status(201).json({ message:'Registration successful. Please wait for admin approval.', user:{ id:user._id, name:user.name, email:user.email, role:user.role } });
  } catch(error) {
    console.error('Register error:', error);
    res.status(500).json({ error:'Server error during registration' });
  }
});

/* ── Login ── */
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error:'Please provide email and password' });

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) return res.status(401).json({ error:'Invalid email or password' });

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(401).json({ error:'Invalid email or password' });

    if (user.role !== 'admin' && !user.isApproved) return res.status(403).json({ error:'Your account is pending admin approval', isPending:true });

    const token = jwt.sign({ userId:user._id, role:user.role }, process.env.JWT_SECRET, { expiresIn:'7d' });

    res.json({
      message:'Login successful', token,
      user:{ id:user._id, name:user.name, email:user.email, role:user.role,
             department:user.department, subject:user.subject, rollNumber:user.rollNumber,
             areasOfInterest:user.areasOfInterest||[], isApproved:user.isApproved }
    });
  } catch(error) {
    console.error('Login error:', error);
    res.status(500).json({ error:'Server error during login' });
  }
});

/* ── Get me ── */
router.get('/me', auth, async (req, res) => {
  try {
    const user = await User.findById(req.userId).select('-password');
    res.json({ user });
  } catch { res.status(500).json({ error:'Server error' }); }
});

/* ── Update student areas of interest ── */
router.put('/interests', auth, async (req, res) => {
  try {
    const { areasOfInterest } = req.body;
    if (req.userRole !== 'student') return res.status(403).json({ error:'Students only' });
    // Accept any free-text interest (max 50 chars each, max 30 items total)
    const filtered = (areasOfInterest||[])
      .map(i => String(i).trim().slice(0,50))
      .filter(i => i.length >= 1)
      .slice(0,30);
    await User.updateOne({ _id: req.userId }, { $set: { areasOfInterest: filtered } });
    res.json({ message:'Areas of interest updated', areasOfInterest: filtered });
  } catch { res.status(500).json({ error:'Server error' }); }
});

/* ── Verify token ── */
router.get('/verify-token', auth, (req, res) => res.json({ valid:true, user:{ id:req.userId, role:req.userRole } }));

module.exports = router;
