import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const INTEREST_SUGGESTIONS = [
  'Web Development','Mobile Development','Data Science','Machine Learning',
  'Artificial Intelligence','Cloud Computing','Cybersecurity','DevOps',
  'UI/UX Design','Blockchain','IoT','Game Development',
  'Python','Java','JavaScript','React','SQL','Networking',
];

const Register = () => {
  const [formData, setFormData] = useState({
    name: '', email: '', password: '', confirmPassword: '',
    role: 'student', rollNumber: '', department: '', subject: '',
    areasOfInterest: []
  });
  const [interestInput, setInterestInput] = useState('');
  const [error,   setError]   = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPwd, setShowPwd] = useState(false);
  const [step,    setStep]    = useState(1); // 1 = account info, 2 = role details
  const { register } = useAuth();
  const navigate = useNavigate();

  const addInterest = (val) => {
    const trimmed = val.trim();
    if (!trimmed || trimmed.length > 50) return;
    if (!formData.areasOfInterest.includes(trimmed))
      setFormData(p => ({ ...p, areasOfInterest: [...p.areasOfInterest, trimmed] }));
    setInterestInput('');
  };
  const removeInterest = (val) =>
    setFormData(p => ({ ...p, areasOfInterest: p.areasOfInterest.filter(i => i !== val) }));

  const handleNext = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.password || !formData.confirmPassword) {
      setError('Please fill in all fields.'); return;
    }
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match.'); return;
    }
    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters.'); return;
    }
    setError('');
    setStep(2);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(''); setSuccess('');
    if (formData.role === 'student' && (!formData.rollNumber || !formData.department)) {
      setError('Students must provide roll number and department.'); return;
    }
    if (formData.role === 'teacher' && !formData.subject) {
      setError('Teachers must provide department.'); return;
    }
    setLoading(true);
    const result = await register({
      name: formData.name, email: formData.email, password: formData.password,
      role: formData.role,
      rollNumber:      formData.role === 'student' ? formData.rollNumber      : undefined,
      department:      formData.role === 'student' ? formData.department      : undefined,
      subject:         formData.role === 'teacher' ? formData.subject         : undefined,
      areasOfInterest: formData.role === 'student' ? formData.areasOfInterest : undefined,
    });
    if (result.success) {
      setSuccess(result.message);
      setTimeout(() => navigate('/login'), 3000);
    } else {
      setError(result.error);
    }
    setLoading(false);
  };

  const inputCls = "w-full px-4 py-2.5 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all bg-gray-50 focus:bg-white";

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "'Inter','Segoe UI',sans-serif" }}>
      {/* Left panel */}
      <div className="hidden lg:flex lg:w-2/5 relative overflow-hidden flex-col justify-between"
        style={{ background: 'linear-gradient(160deg, #1e3a5f 0%, #2563eb 55%, #7c3aed 100%)' }}>
        <div className="absolute inset-0 opacity-10"
          style={{ backgroundImage: 'radial-gradient(circle at 20% 20%, white 1.5px, transparent 1.5px)', backgroundSize: '35px 35px' }}/>
        <div className="relative z-10 p-12 flex flex-col h-full justify-between">
          <div>
            <div className="flex items-center gap-3 mb-12">
              <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138z"/>
                </svg>
              </div>
              <span className="text-xl font-bold text-white tracking-tight">CertifyHub</span>
            </div>
            <h1 className="text-3xl font-extrabold text-white leading-tight mb-4">Start Your<br/>Verified Journey</h1>
            <p className="text-blue-100 text-base mb-10">Join thousands of students and teachers on the platform that makes certificate management intelligent.</p>
            <div className="space-y-5">
              {[
                { step: '01', title: 'Create your account', desc: 'Pick your role — student or teacher' },
                { step: '02', title: 'Upload certificates', desc: 'AI auto-extracts all fields instantly' },
                { step: '03', title: 'Get verified', desc: 'QR & ID verification in seconds' },
                { step: '04', title: 'Track growth', desc: 'AI-powered analytics & recommendations' },
              ].map(s => (
                <div key={s.step} className="flex items-start gap-4">
                  <div className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center shrink-0 text-xs font-bold text-white">{s.step}</div>
                  <div>
                    <p className="text-white font-semibold text-sm">{s.title}</p>
                    <p className="text-blue-200 text-xs">{s.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <p className="text-blue-200 text-xs mt-8">© {new Date().getFullYear()} CertifyHub. All rights reserved.</p>
        </div>
      </div>

      {/* Right — form */}
      <div className="flex-1 bg-gray-50 flex items-center justify-center px-6 py-10 overflow-y-auto">
        <div className="w-full max-w-lg">
          {/* Mobile logo */}
          <div className="flex items-center gap-2 mb-6 lg:hidden">
            <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center">
              <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4z"/>
              </svg>
            </div>
            <span className="text-lg font-bold text-gray-900">CertifyHub</span>
          </div>

          <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-8">
            {/* Header */}
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Create your account</h2>
              <p className="text-gray-500 text-sm mt-1">
                {step === 1 ? 'Step 1 of 2 — Account credentials' : 'Step 2 of 2 — Profile details'}
              </p>
              {/* Progress bar */}
              <div className="mt-3 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-500"
                  style={{ width: step === 1 ? '50%' : '100%', background: 'linear-gradient(90deg,#2563eb,#7c3aed)' }}/>
              </div>
            </div>

            {error && (
              <div className="mb-5 flex items-start gap-3 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm">
                <svg className="w-4 h-4 mt-0.5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
                {error}
              </div>
            )}
            {success && (
              <div className="mb-5 flex items-start gap-3 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl text-sm">
                <svg className="w-4 h-4 mt-0.5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
                {success} Redirecting to login…
              </div>
            )}

            {/* ── STEP 1 ── */}
            {step === 1 && (
              <form onSubmit={handleNext} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Full Name</label>
                  <input type="text" required className={inputCls} placeholder="Your full name"
                    value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })}/>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Email Address</label>
                  <input type="email" required className={inputCls} placeholder="you@college.edu"
                    value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })}/>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Password</label>
                  <div className="relative">
                    <input type={showPwd ? 'text' : 'password'} required className={inputCls + ' pr-10'}
                      placeholder="Min. 6 characters"
                      value={formData.password} onChange={(e) => setFormData({ ...formData, password: e.target.value })}/>
                    <button type="button" onClick={() => setShowPwd(!showPwd)}
                      className="absolute inset-y-0 right-3 flex items-center text-gray-400 hover:text-gray-600">
                      {showPwd
                        ? <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/></svg>
                        : <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                      }
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Confirm Password</label>
                  <input type="password" required className={inputCls} placeholder="Re-enter your password"
                    value={formData.confirmPassword} onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}/>
                </div>
                {/* Role toggle */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">I am a…</label>
                  <div className="grid grid-cols-2 gap-3">
                    {['student','teacher'].map(r => (
                      <button key={r} type="button"
                        onClick={() => setFormData({ ...formData, role: r })}
                        className={`py-3 rounded-xl border-2 text-sm font-semibold transition-all ${
                          formData.role === r
                            ? 'border-blue-600 bg-blue-50 text-blue-700'
                            : 'border-gray-200 bg-white text-gray-600 hover:border-gray-300'
                        }`}>
                        {r === 'student' ? '🎓 Student' : '👩‍🏫 Teacher'}
                      </button>
                    ))}
                  </div>
                </div>
                <button type="submit"
                  className="w-full py-2.5 text-white font-semibold rounded-xl text-sm transition-all shadow-sm hover:shadow-md"
                  style={{ background: 'linear-gradient(135deg, #2563eb, #7c3aed)' }}>
                  Continue →
                </button>
              </form>
            )}

            {/* ── STEP 2 ── */}
            {step === 2 && (
              <form onSubmit={handleSubmit} className="space-y-4">
                {formData.role === 'student' ? (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Roll Number <span className="text-red-500">*</span></label>
                        <input type="text" required className={inputCls} placeholder="e.g. 22CS001"
                          value={formData.rollNumber} onChange={(e) => setFormData({ ...formData, rollNumber: e.target.value })}/>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Department <span className="text-red-500">*</span></label>
                        <input type="text" required className={inputCls} placeholder="e.g. CSE, IT, ECE"
                          value={formData.department} onChange={(e) => setFormData({ ...formData, department: e.target.value })}/>
                      </div>
                    </div>

                    {/* Areas of Interest */}
                    <div className="pt-1">
                      <label className="block text-sm font-medium text-gray-700 mb-0.5">
                        Areas of Interest
                        <span className="ml-1.5 text-xs text-blue-600 font-normal bg-blue-50 px-2 py-0.5 rounded-full">🤖 Powers AI recommendations</span>
                      </label>
                      <p className="text-xs text-gray-400 mb-2">Tell us what you're into — we'll personalise course & certification suggestions just for you.</p>
                      <div className="flex gap-2">
                        <input type="text" placeholder="Type a topic and press Enter or Add…"
                          className={inputCls + ' flex-1'}
                          value={interestInput}
                          onChange={(e) => setInterestInput(e.target.value)}
                          onKeyDown={(e) => { if (e.key==='Enter'){e.preventDefault();addInterest(interestInput);} }}
                        />
                        <button type="button" onClick={() => addInterest(interestInput)}
                          className="px-4 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-medium hover:bg-blue-700 shrink-0">
                          Add
                        </button>
                      </div>
                      {/* Quick-pick chips */}
                      <div className="flex flex-wrap gap-1.5 mt-2">
                        {INTEREST_SUGGESTIONS.filter(s => !formData.areasOfInterest.includes(s)).slice(0,12).map(s => (
                          <button key={s} type="button" onClick={() => addInterest(s)}
                            className="px-2.5 py-1 text-xs bg-gray-100 text-gray-600 rounded-full border border-gray-200 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700 transition-colors">
                            + {s}
                          </button>
                        ))}
                      </div>
                      {/* Selected pills */}
                      {formData.areasOfInterest.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 mt-2 p-3 bg-blue-50 rounded-xl border border-blue-100">
                          <p className="w-full text-xs text-blue-600 font-medium mb-1">Your interests:</p>
                          {formData.areasOfInterest.map(i => (
                            <span key={i} className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-600 text-white rounded-full text-xs font-medium">
                              {i}
                              <button type="button" onClick={() => removeInterest(i)}
                                className="text-blue-200 hover:text-white ml-0.5 font-bold leading-none">×</button>
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </>
                ) : (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">Department <span className="text-red-500">*</span></label>
                    <input type="text" required className={inputCls} placeholder="e.g. CSE, IT, ECE, MECH"
                      value={formData.subject} onChange={(e) => setFormData({ ...formData, subject: e.target.value })}/>
                    <p className="text-xs text-gray-400 mt-1">You'll see only students from your department.</p>
                  </div>
                )}

                <div className="flex gap-3 pt-1">
                  <button type="button" onClick={() => { setStep(1); setError(''); }}
                    className="flex-1 py-2.5 border border-gray-300 text-gray-700 font-semibold rounded-xl text-sm hover:bg-gray-50 transition-all">
                    ← Back
                  </button>
                  <button type="submit" disabled={loading}
                    className="flex-1 py-2.5 text-white font-semibold rounded-xl text-sm transition-all shadow-sm hover:shadow-md flex items-center justify-center gap-2 disabled:opacity-60"
                    style={{ background: 'linear-gradient(135deg, #2563eb, #7c3aed)' }}>
                    {loading
                      ? <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"/><span>Creating…</span></>
                      : 'Create Account'}
                  </button>
                </div>
              </form>
            )}

            <div className="mt-6 text-center">
              <p className="text-sm text-gray-500">
                Already have an account?{' '}
                <Link to="/login" className="text-blue-600 font-semibold hover:text-blue-700">Sign in</Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;
