import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { adminAPI, certificateAPI } from '../services/api';
import { formatDate, getErrorMessage } from '../utils/helpers';
import CertificateCard from '../components/CertificateCard';

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [stats, setStats] = useState(null);
  const [pendingUsers, setPendingUsers] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [allCertificates, setAllCertificates] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [userFilter, setUserFilter] = useState('all');

  useEffect(() => {
    if (activeTab === 'dashboard') {
      fetchDashboardStats();
    } else if (activeTab === 'approvals') {
      fetchPendingApprovals();
    } else if (activeTab === 'users') {
      fetchAllUsers();
    } else if (activeTab === 'certificates') {
      fetchAllCertificates();
    }
  }, [activeTab]);

  const fetchDashboardStats = async () => {
    setLoading(true);
    try {
      const response = await adminAPI.getDashboardStats();
      setStats(response.data);
    } catch (error) {
      setError(getErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  const fetchPendingApprovals = async () => {
    setLoading(true);
    try {
      const response = await adminAPI.getPendingApprovals();
      setPendingUsers(response.data.pendingUsers);
    } catch (error) {
      setError(getErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  const fetchAllUsers = async () => {
    setLoading(true);
    try {
      const response = await adminAPI.getUsers({ role: userFilter === 'all' ? '' : userFilter });
      setAllUsers(response.data.users);
    } catch (error) {
      setError(getErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  const fetchAllCertificates = async () => {
    setLoading(true);
    try {
      const response = await certificateAPI.getAllCertificates();
      setAllCertificates(response.data.certificates);
    } catch (error) {
      setError(getErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (userId) => {
    try {
      await adminAPI.approveUser(userId);
      setPendingUsers(pendingUsers.filter(u => u._id !== userId));
      alert('User approved successfully');
      fetchDashboardStats();
    } catch (error) {
      alert(getErrorMessage(error));
    }
  };

  const handleReject = async (userId) => {
    if (window.confirm('Are you sure you want to reject this user?')) {
      try {
        await adminAPI.rejectUser(userId);
        setPendingUsers(pendingUsers.filter(u => u._id !== userId));
        alert('User rejected successfully');
        fetchDashboardStats();
      } catch (error) {
        alert(getErrorMessage(error));
      }
    }
  };

  const handleDeleteUser = async (userId) => {
    if (window.confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
      try {
        await adminAPI.deleteUser(userId);
        setAllUsers(allUsers.filter(u => u._id !== userId));
        alert('User deleted successfully');
      } catch (error) {
        alert(getErrorMessage(error));
      }
    }
  };

  const handleDownloadCertificate = async (certId) => {
    try {
      const response = await certificateAPI.download(certId);
      const blob = response.data; // already a Blob — do NOT wrap again
      const disposition = response.headers?.['content-disposition'] || '';
      const nameMatch   = disposition.match(/filename[^;=\n]*=([^;\n]*)/i);
      const fileName    = nameMatch ? nameMatch[1].replace(/['"]/g,'').trim() : `certificate-${certId}`;
      const url  = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href  = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      alert(getErrorMessage(error));
    }
  };

  const handleDeleteCertificate = async (certId) => {
    try {
      await certificateAPI.delete(certId);
      setAllCertificates(allCertificates.filter(c => c._id !== certId));
      alert('Certificate deleted successfully');
    } catch (error) {
      alert(getErrorMessage(error));
    }
  };

  const handleVerifyCertificate = async (certId) => {
    try {
      await certificateAPI.verify(certId);
      setAllCertificates(allCertificates.map(cert =>
        cert._id === certId
          ? { ...cert, verificationStatus: 'verified', verificationMethod: 'manual', verifiedAt: new Date() }
          : cert
      ));
      alert('Certificate verified successfully!');
    } catch (error) {
      alert(getErrorMessage(error));
    }
  };

  const TABS = [
    { id: 'dashboard',     label: 'Dashboard',          icon: '🏠' },
    { id: 'approvals',     label: 'Pending Approvals',  icon: '⏳', badge: stats?.pendingApprovals },
    { id: 'users',         label: 'Manage Users',       icon: '👥' },
    { id: 'certificates',  label: 'Certificates',       icon: '📜' },
  ];

  return (
    <div className="min-h-screen" style={{ background: '#f1f5f9', fontFamily: "'Inter','Segoe UI',sans-serif" }}>
      {/* Top nav bar */}
      <div className="sticky top-0 z-30 shadow-sm" style={{ background: 'linear-gradient(135deg,#1e3a5f,#2563eb)' }}>
        <div className="max-w-7xl mx-auto px-6 py-0 flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
              <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0z"/>
              </svg>
            </div>
            <span className="text-white font-bold text-lg tracking-tight">CertifyHub</span>
            <span className="hidden sm:inline-block px-2 py-0.5 bg-white/20 text-white text-xs rounded-full font-medium">Admin</span>
          </div>
          <div className="text-blue-100 text-sm hidden sm:block">{new Date().toLocaleDateString('en-IN',{weekday:'short',day:'numeric',month:'short',year:'numeric'})}</div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {/* Page title */}
        <div className="mb-6">
          <h1 className="text-2xl font-extrabold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-500 text-sm mt-1">Manage users, approvals, and certificates</p>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 mb-6 overflow-hidden">
          <div className="border-b border-gray-100">
            <nav className="flex overflow-x-auto scrollbar-hide">
              {TABS.map(tab => (
                <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-5 py-4 text-sm font-semibold whitespace-nowrap transition-all ${
                    activeTab === tab.id
                      ? 'border-b-2 border-blue-600 text-blue-700 bg-blue-50/50'
                      : 'text-gray-500 hover:text-gray-800 hover:bg-gray-50'
                  }`}>
                  <span>{tab.icon}</span>
                  {tab.label}
                  {tab.badge > 0 && (
                    <span className="ml-1 bg-red-500 text-white px-1.5 py-0.5 rounded-full text-xs font-bold">{tab.badge}</span>
                  )}
                </button>
              ))}
            </nav>
          </div>

          {/* Tab Content */}
          <div className="p-6">
            {error && (
              <div className="flex items-center gap-3 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-4 text-sm">
                <svg className="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                {error}
              </div>
            )}

            {loading ? (
              <div className="text-center py-16">
                <div className="inline-block animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600 mb-4"></div>
                <p className="text-gray-500 text-sm">Loading data…</p>
              </div>
            ) : (
              <>
                {/* Dashboard Tab */}
                {activeTab === 'dashboard' && stats && (
                  <div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                      <div className="bg-blue-50 rounded-lg p-6 cursor-pointer hover:shadow-md hover:bg-blue-100 transition-all" onClick={() => { setUserFilter('student'); setActiveTab('users'); }}>
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-blue-600 text-sm font-medium">Total Students</p>
                            <p className="text-3xl font-bold text-blue-900 mt-2">{stats.totalStudents}</p>
                            <p className="text-xs text-blue-500 mt-1">Click to view all students →</p>
                          </div>
                          <div className="bg-blue-100 rounded-full p-3">
                            <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                            </svg>
                          </div>
                        </div>
                      </div>

                      <div className="bg-green-50 rounded-lg p-6 cursor-pointer hover:shadow-md hover:bg-green-100 transition-all" onClick={() => { setUserFilter('teacher'); setActiveTab('users'); }}>
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-green-600 text-sm font-medium">Total Teachers</p>
                            <p className="text-3xl font-bold text-green-900 mt-2">{stats.totalTeachers}</p>
                            <p className="text-xs text-green-500 mt-1">Click to view all teachers →</p>
                          </div>
                          <div className="bg-green-100 rounded-full p-3">
                            <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            </svg>
                          </div>
                        </div>
                      </div>

                      <div className="bg-yellow-50 rounded-lg p-6 cursor-pointer hover:shadow-md hover:bg-yellow-100 transition-all" onClick={() => setActiveTab('approvals')}>
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-yellow-600 text-sm font-medium">Pending Approvals</p>
                            <p className="text-3xl font-bold text-yellow-900 mt-2">{stats.pendingApprovals}</p>
                            <p className="text-xs text-yellow-500 mt-1">Click to review approvals →</p>
                          </div>
                          <div className="bg-yellow-100 rounded-full p-3">
                            <svg className="w-8 h-8 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                          </div>
                        </div>
                      </div>

                      <div className="bg-purple-50 rounded-lg p-6 cursor-pointer hover:shadow-md hover:bg-purple-100 transition-all" onClick={() => setActiveTab('certificates')}>
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-purple-600 text-sm font-medium">Total Certificates</p>
                            <p className="text-3xl font-bold text-purple-900 mt-2">{stats.totalCertificates}</p>
                            <p className="text-xs text-purple-500 mt-1">Click to view all certificates →</p>
                          </div>
                          <div className="bg-purple-100 rounded-full p-3">
                            <svg className="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Recent Activity */}
                    <div className="bg-white rounded-lg border border-gray-200 p-6">
                      <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
                      <div className="space-y-3">
                        {stats.recentActivity && stats.recentActivity.length > 0 ? (
                          stats.recentActivity.map((activity, index) => (
                            <div
                              key={index}
                              className="flex items-center justify-between py-2 border-b last:border-b-0 cursor-pointer hover:bg-gray-50 rounded-md px-2 transition-colors"
                              onClick={() => {
                                if (!activity.isApproved) {
                                  setActiveTab('approvals');
                                } else {
                                  setUserFilter(activity.role || 'all');
                                  setActiveTab('users');
                                }
                              }}
                            >
                              <div className="flex items-center">
                                <div className={`w-2 h-2 rounded-full mr-3 ${activity.isApproved ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
                                <div>
                                  <p className="font-medium">{activity.name}</p>
                                  <p className="text-sm text-gray-500">
                                    {activity.role} • {activity.isApproved ? 'Approved' : 'Pending'} • <span className="text-blue-500 text-xs">View →</span>
                                  </p>
                                </div>
                              </div>
                              <span className="text-sm text-gray-500">{formatDate(activity.registeredAt)}</span>
                            </div>
                          ))
                        ) : (
                          <p className="text-gray-500 text-center py-4">No recent activity</p>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* Pending Approvals Tab */}
                {activeTab === 'approvals' && (
                  <div>
                    <div className="flex items-center justify-between mb-5">
                      <h2 className="text-lg font-bold text-gray-800">Pending Registrations</h2>
                      {pendingUsers.length > 0 && (
                        <span className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm font-semibold">
                          {pendingUsers.length} awaiting review
                        </span>
                      )}
                    </div>
                    {pendingUsers.length === 0 ? (
                      <div className="text-center py-16 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200">
                        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                          <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                        <p className="text-gray-700 font-semibold">All caught up!</p>
                        <p className="text-gray-400 text-sm mt-1">No pending approvals right now.</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                        {pendingUsers.map((user) => (
                          <div key={user._id} className="approval-card">
                            <div className="flex justify-between items-start mb-3">
                              <div className="flex items-center gap-3">
                                <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-white text-sm ${
                                  user.role === 'student' ? 'bg-blue-500' : 'bg-emerald-500'
                                }`}>
                                  {user.name?.charAt(0)?.toUpperCase()}
                                </div>
                                <div>
                                  <h3 className="font-bold text-gray-900 text-base">{user.name}</h3>
                                  <p className="text-xs text-gray-500">{user.email}</p>
                                </div>
                              </div>
                              <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                                user.role === 'student' ? 'bg-blue-100 text-blue-700' : 'bg-emerald-100 text-emerald-700'
                              }`}>
                                {user.role === 'student' ? '🎓 Student' : '👩‍🏫 Teacher'}
                              </span>
                            </div>

                            <div className="bg-gray-50 rounded-xl p-3 mb-4 space-y-1.5">
                              {user.rollNumber && (
                                <div className="flex items-center gap-2 text-sm">
                                  <span className="text-gray-400 w-20 shrink-0 text-xs font-semibold uppercase">Roll No</span>
                                  <span className="text-gray-700 font-medium">{user.rollNumber}</span>
                                </div>
                              )}
                              {(user.department || user.subject) && (
                                <div className="flex items-center gap-2 text-sm">
                                  <span className="text-gray-400 w-20 shrink-0 text-xs font-semibold uppercase">Dept</span>
                                  <span className="text-gray-700 font-medium">{user.department || user.subject}</span>
                                </div>
                              )}
                              <div className="flex items-center gap-2 text-sm">
                                <span className="text-gray-400 w-20 shrink-0 text-xs font-semibold uppercase">Registered</span>
                                <span className="text-gray-500">{formatDate(user.registeredAt)}</span>
                              </div>
                            </div>

                            <div className="flex gap-2">
                              <button
                                onClick={() => handleApprove(user._id)}
                                className="flex-1 py-2 px-4 rounded-xl text-sm font-bold text-white transition-all hover:shadow-md"
                                style={{ background:'linear-gradient(135deg,#16a34a,#15803d)' }}
                              >
                                ✓ Approve
                              </button>
                              <button
                                onClick={() => handleReject(user._id)}
                                className="flex-1 py-2 px-4 rounded-xl text-sm font-bold text-white transition-all hover:shadow-md"
                                style={{ background:'linear-gradient(135deg,#dc2626,#b91c1c)' }}
                              >
                                ✗ Reject
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Manage Users Tab */}
                {activeTab === 'users' && (
                  <div>
                    <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
                      <h2 className="text-lg font-bold text-gray-800">
                        All Users
                        {allUsers.length > 0 && <span className="ml-2 text-sm font-normal text-gray-400">({allUsers.length} total)</span>}
                      </h2>
                      <div className="flex gap-2">
                        {['all','student','teacher'].map(f => (
                          <button key={f}
                            onClick={() => setUserFilter(f)}
                            className={`px-4 py-2 rounded-xl text-sm font-semibold border transition-all ${
                              userFilter === f
                                ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                                : 'bg-white text-gray-600 border-gray-200 hover:border-blue-300 hover:text-blue-600'
                            }`}>
                            {f === 'all' ? 'All' : f === 'student' ? '🎓 Students' : '👩‍🏫 Teachers'}
                          </button>
                        ))}
                      </div>
                    </div>

                    {allUsers.length === 0 ? (
                      <div className="text-center py-16 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200">
                        <p className="text-gray-500 font-medium">No users found</p>
                        <p className="text-gray-400 text-sm mt-1">Try changing the filter</p>
                      </div>
                    ) : (
                      <div className="overflow-x-auto rounded-xl border border-gray-200 shadow-sm">
                        <table className="admin-table min-w-full bg-white">
                          <thead className="bg-gray-50">
                            <tr>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Role</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Details</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Certificates / Status</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-200">
                            {allUsers.map((user) => (
                              <tr key={user._id} className="hover:bg-gray-50 transition-colors">
                                <td className="px-6 py-4 whitespace-nowrap font-medium">{user.name}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{user.email}</td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                                    user.role === 'student' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                                  }`}>
                                    {user.role}
                                  </span>
                                </td>
                                <td className="px-6 py-4 text-sm">
                                  {user.role === 'teacher' ? (
                                    <div className="text-gray-700">
                                      {user.department
                                        ? <span className="inline-flex items-center gap-1"><span className="font-medium">Dept:</span> {user.department}</span>
                                        : user.subject
                                          ? <span className="inline-flex items-center gap-1"><span className="font-medium">Dept:</span> {user.subject}</span>
                                          : <span className="text-gray-400 italic">No department</span>
                                      }
                                    </div>
                                  ) : (
                                    <>
                                      {user.rollNumber && <div><span className="font-medium">Roll:</span> {user.rollNumber}</div>}
                                      {user.department && <div><span className="font-medium">Dept:</span> {user.department}</div>}
                                    </>
                                  )}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  {user.role === 'teacher' ? (
                                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-semibold ${
                                      user.isApproved ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                                    }`}>
                                      {user.isApproved ? '✓ Verified' : '✗ Not Verified'}
                                    </span>
                                  ) : (
                                    <span className="font-medium text-gray-800">{user.certificateCount || 0}</span>
                                  )}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <button
                                    onClick={() => handleDeleteUser(user._id)}
                                    className="text-red-600 hover:text-red-800 text-sm font-medium hover:underline"
                                  >
                                    Delete
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}

                {/* All Certificates Tab */}
                {activeTab === 'certificates' && (
                  <div>
                    {allCertificates.length === 0 ? (
                      <p className="text-center py-12 text-gray-600">No certificates found</p>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {allCertificates.map((cert) => (
                          <CertificateCard
                            key={cert._id}
                            certificate={cert}
                            showStudent={true}
                            userRole="admin"
                            onDownload={handleDownloadCertificate}
                            onDelete={handleDeleteCertificate}
                            onVerify={handleVerifyCertificate}
                          />
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
