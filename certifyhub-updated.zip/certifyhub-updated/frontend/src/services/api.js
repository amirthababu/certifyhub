import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const api = axios.create({ baseURL: API_URL, headers: { 'Content-Type': 'application/json' } });

api.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
}, error => Promise.reject(error));

export const authAPI = {
  register:         (data)                => api.post('/auth/register', data),
  login:            (data)                => api.post('/auth/login', data),
  getMe:            ()                    => api.get('/auth/me'),
  verifyToken:      ()                    => api.get('/auth/verify-token'),
  updateInterests:  (areasOfInterest)     => api.put('/auth/interests', { areasOfInterest }),
};

export const certificateAPI = {
  upload:           (formData)            => api.post('/certificates/upload', formData, { headers:{ 'Content-Type':'multipart/form-data' } }),
  ocrExtract:       (formData)            => api.post('/certificates/ocr-extract', formData, { headers:{ 'Content-Type':'multipart/form-data' } }),
  getMyCertificates:()                    => api.get('/certificates/my-certificates'),
  getAllCertificates:(params)             => api.get('/certificates/all', { params }),
  search:           (params)             => api.get('/certificates/search', { params }),
  download:         (id)                 => api.get(`/certificates/download/${id}`, {
    responseType: 'blob',
    // expose Content-Disposition so we can read the real filename
    headers: { 'Cache-Control': 'no-cache' }
  }),
  view:             (id)                 => `${api.defaults.baseURL}/certificates/view/${id}`,
  viewIframe:       (id)                 => { const t=localStorage.getItem('token'); return `${api.defaults.baseURL}/certificates/view-token/${id}${t?`?token=${encodeURIComponent(t)}`:''}` },
  delete:           (id)                 => api.delete(`/certificates/${id}`),
  verify:           (id)                 => api.put(`/certificates/verify/${id}`),
  getStats:         ()                   => api.get('/certificates/stats/overview'),
};

export const adminAPI = {
  getPendingApprovals: ()                => api.get('/admin/pending-approvals'),
  approveUser:        (userId)           => api.put(`/admin/approve/${userId}`),
  rejectUser:         (userId)           => api.delete(`/admin/reject/${userId}`),
  getUsers:           (params)           => api.get('/admin/users', { params }),
  getStudents:        ()                 => api.get('/admin/students'),
  deleteUser:         (userId)           => api.delete(`/admin/users/${userId}`),
  getDashboardStats:  ()                 => api.get('/admin/dashboard/stats'),
};

export const mlAPI = {
  getMyAnalysis:      ()                 => api.get('/ml/growth-analysis'),
  getStudentAnalysis: (studentId)        => api.get(`/ml/growth-analysis/${studentId}`),
};

export const feedbackAPI = {
  send:        (data)                    => api.post('/feedback', data),
  getSent:     (studentId)               => api.get('/feedback/sent', { params: studentId ? { studentId } : {} }),
  getReceived: ()                        => api.get('/feedback/received'),
  getForStudent:(studentId)              => api.get(`/feedback/student/${studentId}`),
  markRead:    (id)                      => api.put(`/feedback/${id}/read`),
  markAllRead: ()                        => api.put('/feedback/read-all'),
  delete:      (id)                      => api.delete(`/feedback/${id}`),
  getStudents: ()                        => api.get('/feedback/students'),
};

export const notificationAPI = {
  getNotifications:   ()                 => api.get('/notifications'),
  markAsRead:         (id)               => api.put(`/notifications/${id}/read`),
  markAllAsRead:      ()                 => api.put('/notifications/read-all'),
  deleteNotification: (id)               => api.delete(`/notifications/${id}`),
  clearAll:           ()                 => api.delete('/notifications/clear-all'),
};

export default api;
