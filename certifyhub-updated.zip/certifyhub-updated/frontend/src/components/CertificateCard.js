import React, { useState } from 'react';
import { certificateAPI } from '../services/api';

const CertificateCard = ({ certificate, onDownload, onDelete, onVerify, onView, showStudent = false, userRole }) => {
  const [showPreview, setShowPreview] = useState(false);

  const formatDate = (date) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric', month: 'short', day: 'numeric'
    });
  };

  const getVerificationBadge = () => {
    if (certificate.verificationStatus === 'verified') {
      return (
        <span className="cert-badge cert-badge-verified">
          <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          Verified
        </span>
      );
    }
    return <span className="cert-badge cert-badge-unverified">Unverified</span>;
  };

  const getCategoryColor = (category) => {
    const colors = {
      'Programming': 'cert-cat-programming',
      'Backend': 'cert-cat-backend',
      'Frontend': 'cert-cat-frontend',
      'Database': 'cert-cat-database',
      'Cloud': 'cert-cat-cloud',
      'AI/ML': 'cert-cat-aiml',
      'Mobile': 'cert-cat-mobile',
      'Other': 'cert-cat-other'
    };
    return colors[category] || 'cert-cat-other';
  };

  const handleView = () => {
    // Use viewIframe which embeds token in URL - avoids "no authentication token" errors
    const url = certificateAPI.viewIframe(certificate._id);
    window.open(url, '_blank');
  };

  return (
    <div className="cert-card">
      {/* Top accent bar based on category */}
      <div className={`cert-card-accent ${getCategoryColor(certificate.category)}`} />

      <div className="cert-card-body">
        {/* Header */}
        <div className="cert-card-header">
          <h3 className="cert-card-title">{certificate.title}</h3>
          <div className="flex flex-col gap-1 items-end shrink-0">
            {getVerificationBadge()}
            <span className={`cert-badge cert-badge-category ${getCategoryColor(certificate.category)}`}>
              {certificate.category}
            </span>
          </div>
        </div>

        {/* Student Info (for teachers/admins) */}
        {showStudent && certificate.student && (
          <div className="cert-student-info">
            <div className="flex items-center gap-1 mb-1">
              <svg className="w-4 h-4 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                  d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
              <span className="font-medium text-gray-800">{certificate.student.name}</span>
            </div>
            <div className="flex flex-wrap gap-2 text-xs text-gray-500">
              {certificate.student.rollNumber && (
                <span className="cert-meta-pill">#{certificate.student.rollNumber}</span>
              )}
              {certificate.student.department && (
                <span className="cert-meta-pill dept-pill">{certificate.student.department}</span>
              )}
            </div>
          </div>
        )}

        {/* Description */}
        <p className="cert-description">{certificate.description}</p>

        {/* Details Grid */}
        <div className="cert-details-grid">
          <div className="cert-detail-item">
            <p className="cert-detail-label">Issue Date</p>
            <p className="cert-detail-value">{formatDate(certificate.issueDate)}</p>
          </div>
          <div className="cert-detail-item">
            <p className="cert-detail-label">Uploaded</p>
            <p className="cert-detail-value">{formatDate(certificate.uploadedAt)}</p>
          </div>
          {certificate.issuer && certificate.issuer !== '' && (
            <div className="cert-detail-item">
              <p className="cert-detail-label">Issuer</p>
              <p className="cert-detail-value">{certificate.issuer}</p>
            </div>
          )}
          <div className="cert-detail-item">
            <p className="cert-detail-label">Skill Level</p>
            <p className={`cert-skill-level cert-skill-${certificate.skillLevel?.toLowerCase()}`}>
              {certificate.skillLevel}
            </p>
          </div>
        </div>

        {/* Verification Details */}
        {certificate.verificationStatus === 'verified' && certificate.verificationMethod && (
          <div className="cert-verified-box">
            <div className="flex items-center gap-1">
              <svg className="w-3.5 h-3.5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
              <span className="text-xs text-green-800 font-medium">
                {certificate.verificationMethod === 'qr_code' || certificate.verificationMethod === 'certificate_id'
                  ? 'Autoverified'
                  : 'Verified by Teacher'}
              </span>
            </div>
            {certificate.verifiedAt && (
              <p className="text-xs text-green-600 mt-0.5 ml-5">on {formatDate(certificate.verifiedAt)}</p>
            )}
          </div>
        )}

        {/* Keywords */}
        {certificate.keywords && certificate.keywords.length > 0 && (
          <div className="cert-keywords">
            {certificate.keywords.slice(0, 5).map((keyword, index) => (
              <span key={index} className="cert-keyword-tag">{keyword}</span>
            ))}
          </div>
        )}

        {/* Action Buttons */}
        <div className="cert-actions">
          {onView && (
            <button onClick={handleView} className="cert-btn cert-btn-view" title="View Certificate">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                  d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                  d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
              View
            </button>
          )}

          {onDownload && (
            <button onClick={() => onDownload(certificate._id)} className="cert-btn cert-btn-download" title="Download Certificate">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                  d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              Download
            </button>
          )}

          {onVerify && certificate.verificationStatus !== 'verified' && (userRole === 'teacher' || userRole === 'admin') && (
            <button onClick={() => onVerify(certificate._id)} className="cert-btn cert-btn-verify" title="Verify Certificate">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                  d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Verify
            </button>
          )}

          {onDelete && (
            <button
              onClick={() => { if (window.confirm('Delete this certificate?')) onDelete(certificate._id); }}
              className="cert-btn cert-btn-delete"
              title="Delete Certificate"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                  d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
              Delete
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default CertificateCard;
