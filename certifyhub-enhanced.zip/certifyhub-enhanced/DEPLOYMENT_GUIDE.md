# CertifyHub - Quick Start & Deployment Guide

## 🚀 Quick Start (5 Minutes)

### Step 1: Install Dependencies

```bash
# Backend
cd certifyhub/backend
npm install

# Frontend (in new terminal)
cd certifyhub/frontend
npm install
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```

### Step 2: Configure Environment

**Backend** - Create `backend/.env`:
```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/certifyhub
JWT_SECRET=your-random-secret-key-min-32-characters-long
NODE_ENV=development
CLIENT_URL=http://localhost:3000
```

**Frontend** - Create `frontend/.env`:
```env
REACT_APP_API_URL=http://localhost:5000/api
REACT_APP_SOCKET_URL=http://localhost:5000
```

### Step 3: Start MongoDB

```bash
# Method 1: Using systemctl
sudo systemctl start mongod
sudo systemctl status mongod

# Method 2: Direct command
mongod --dbpath /data/db

# Method 3: Using Docker
docker run -d -p 27017:27017 --name mongodb mongo:latest
```

### Step 4: Create Admin Account

```bash
cd backend
npm run create-admin
# Enter: Admin Name, Email, Password
```

### Step 5: Start Application

**Terminal 1 - Backend:**
```bash
cd backend
npm run dev
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm start
```

**Access Application:**
- Frontend: http://localhost:3000
- Backend API: http://localhost:5000
- MongoDB: mongodb://localhost:27017

## 📦 Project Structure Overview

```
certifyhub/
├── backend/               # Node.js + Express Backend
│   ├── models/           # MongoDB Models
│   ├── routes/           # API Routes
│   ├── services/         # Business Logic
│   ├── middleware/       # Auth, Upload
│   ├── scripts/          # Utilities
│   ├── uploads/          # Certificate Files
│   └── server.js         # Entry Point
├── frontend/             # React Frontend
│   └── src/
│       ├── components/   # Reusable Components
│       ├── pages/        # Page Components
│       ├── services/     # API & Socket
│       └── context/      # State Management
└── README.md
```

## 🧪 Testing Workflow

### 1. Create Test Accounts

**Register Student:**
```
Name: John Doe
Email: john@test.com
Password: password123
Role: Student
Roll Number: CS001
Department: Computer Science
```

**Register Teacher:**
```
Name: Jane Smith
Email: jane@test.com
Password: password123
Role: Teacher
Subject: Data Structures
```

### 2. Admin Approval

1. Login as admin at http://localhost:3000/login
2. Navigate to "Pending Approvals" tab
3. Approve both student and teacher accounts

### 3. Test Student Features

1. Login as student (john@test.com)
2. Upload certificates:
   - Title: "Python for Data Science"
   - Description: "Completed Python basics and data analysis"
   - Issue Date: Select a date
   - Issuer: Coursera (optional)
   - Certificate ID: ABC123 (optional)
   - Upload PDF/JPG file

3. Upload 5-10 more certificates with varied content
4. Click "View AI Growth Analysis"
5. Explore ML predictions and recommendations

### 4. Test Teacher Features

1. Login as teacher (jane@test.com)
2. View all students
3. Search certificates: "Python", "React", "Java"
4. Filter by year and verification status
5. Check notifications bell for real-time updates

### 5. Test Real-Time Notifications

1. Open two browsers:
   - Browser 1: Student logged in
   - Browser 2: Teacher logged in
2. In Browser 1: Upload a certificate
3. In Browser 2: Notification appears instantly

## 🔧 Common Issues & Solutions

### Issue: MongoDB Connection Refused

```bash
Error: connect ECONNREFUSED 127.0.0.1:27017
```

**Solution:**
```bash
# Check if MongoDB is running
sudo systemctl status mongod

# Start MongoDB
sudo systemctl start mongod

# Or create data directory and start manually
sudo mkdir -p /data/db
sudo mongod
```

### Issue: Port 5000 Already in Use

```bash
Error: listen EADDRINUSE: address already in use :::5000
```

**Solution:**
```bash
# Find process using port 5000
lsof -i :5000

# Kill the process
kill -9 <PID>

# Or change port in backend/.env
PORT=5001
```

### Issue: Frontend CORS Error

```bash
Access to XMLHttpRequest blocked by CORS policy
```

**Solution:**
1. Check `backend/.env` has correct `CLIENT_URL=http://localhost:3000`
2. Restart backend server
3. Clear browser cache

### Issue: Socket.io Not Connecting

**Solution:**
1. Verify backend is running
2. Check `frontend/.env` has correct `REACT_APP_SOCKET_URL`
3. Open browser console and look for connection errors
4. Restart both frontend and backend

### Issue: File Upload Fails

```bash
Error: Only PDF, JPG, and PNG files are allowed
```

**Solution:**
1. Ensure file is PDF, JPG, or PNG
2. File size should be under 10MB
3. Check `backend/uploads/certificates` directory exists and has write permissions

## 📊 Feature Testing Checklist

### Admin Dashboard
- [ ] View statistics (students, teachers, certificates)
- [ ] Approve student registration
- [ ] Approve teacher registration
- [ ] Reject registration
- [ ] View all users
- [ ] Delete user
- [ ] View all certificates
- [ ] Delete certificate

### Teacher Dashboard
- [ ] View all students
- [ ] Click student card to view certificates
- [ ] Search certificates using NLP
- [ ] Filter by year
- [ ] Filter by verification status
- [ ] Download certificate
- [ ] Receive real-time notifications
- [ ] Mark notifications as read
- [ ] View ML growth analysis (if teacher has certificates)

### Student Dashboard
- [ ] Upload certificate
- [ ] View all uploaded certificates
- [ ] Download own certificate
- [ ] Delete own certificate
- [ ] See verification status
- [ ] View certificate count
- [ ] Access ML growth analysis

### ML Analysis
- [ ] Skill Level Score displayed
- [ ] Career Readiness Score displayed
- [ ] Career role predictions shown
- [ ] Recommendations provided
- [ ] Growth chart rendered
- [ ] Peer comparison shown
- [ ] Category distribution displayed

### Certificate Verification
- [ ] Auto-verification with Certificate ID
- [ ] Auto-verification with QR Code
- [ ] Manual verification by teacher/admin
- [ ] Verified badge displays correctly

### NLP Search
- [ ] Search "Python" returns relevant certificates
- [ ] Search "React course" returns frontend certificates
- [ ] Search "Java backend" returns backend certificates
- [ ] Auto-categorization works correctly
- [ ] Skill level detection accurate

## 🚀 Production Deployment

### Environment Setup

**Backend Production .env:**
```env
PORT=5000
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/certifyhub
JWT_SECRET=use-very-long-random-string-min-64-chars
NODE_ENV=production
CLIENT_URL=https://yourdomain.com
```

**Frontend Production .env:**
```env
REACT_APP_API_URL=https://api.yourdomain.com/api
REACT_APP_SOCKET_URL=https://api.yourdomain.com
```

### Build Commands

```bash
# Frontend
cd frontend
npm run build

# Backend (no build needed, but ensure all dependencies installed)
cd backend
npm install --production
```

### Deployment Options

#### Option 1: Heroku

**Backend:**
```bash
cd backend
heroku create certifyhub-api
heroku addons:create mongolab
heroku config:set JWT_SECRET=your-secret
heroku config:set CLIENT_URL=https://certifyhub.herokuapp.com
git push heroku main
```

**Frontend:**
```bash
cd frontend
# Update .env with Heroku backend URL
npm run build
# Deploy to Netlify/Vercel
```

#### Option 2: AWS EC2

1. Launch Ubuntu EC2 instance
2. Install Node.js and MongoDB
3. Clone repository
4. Setup PM2 for process management:
```bash
npm install -g pm2
pm2 start backend/server.js --name certifyhub-api
pm2 startup
pm2 save
```

#### Option 3: Docker

**Dockerfile (Backend):**
```dockerfile
FROM node:18
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 5000
CMD ["node", "server.js"]
```

**docker-compose.yml:**
```yaml
version: '3.8'
services:
  mongodb:
    image: mongo:latest
    ports:
      - "27017:27017"
    volumes:
      - mongodb_data:/data/db
  
  backend:
    build: ./backend
    ports:
      - "5000:5000"
    environment:
      - MONGODB_URI=mongodb://mongodb:27017/certifyhub
      - JWT_SECRET=your-secret-key
    depends_on:
      - mongodb
  
  frontend:
    build: ./frontend
    ports:
      - "3000:3000"
    depends_on:
      - backend

volumes:
  mongodb_data:
```

## 📈 Monitoring & Maintenance

### Log Files

```bash
# View backend logs
cd backend
tail -f logs/app.log  # if logging to file

# PM2 logs
pm2 logs certifyhub-api

# Docker logs
docker logs certifyhub-backend
```

### Database Backup

```bash
# Backup MongoDB
mongodump --db certifyhub --out ./backups/$(date +%Y%m%d)

# Restore MongoDB
mongorestore --db certifyhub ./backups/20240101/certifyhub
```

### Performance Optimization

1. **Enable MongoDB Indexing** (already done in models)
2. **Use Redis for Sessions** (future enhancement)
3. **Implement Pagination** for large datasets
4. **CDN for Static Files**
5. **Gzip Compression**

## 🔒 Security Checklist

- [x] JWT token authentication
- [x] Bcrypt password hashing (10 rounds)
- [x] Role-based access control
- [x] File upload validation
- [x] CORS configuration
- [ ] Rate limiting (add in production)
- [ ] Helmet.js for security headers (add in production)
- [ ] HTTPS only (production)
- [ ] Input sanitization (add mongoose-sanitize)

## 📞 Support

### Getting Help

1. Check README.md for feature documentation
2. Review FRONTEND_GUIDE.md for frontend code examples
3. Check console logs for errors
4. Verify all dependencies are installed
5. Ensure MongoDB is running

### Debug Mode

**Enable detailed logging:**
```env
NODE_ENV=development
DEBUG=*
```

**Check application health:**
```bash
curl http://localhost:5000/health
```

## 🎉 Success Criteria

Your installation is successful when:

1. ✅ Backend server runs on port 5000
2. ✅ Frontend loads at http://localhost:3000
3. ✅ Admin can login and approve users
4. ✅ Students can upload certificates
5. ✅ Teachers receive real-time notifications
6. ✅ ML analysis displays predictions
7. ✅ NLP search returns relevant results
8. ✅ Certificates can be downloaded

---

**You're now ready to use CertifyHub! 🎓**

For questions or issues, refer to the README.md or check the console logs for detailed error messages.
