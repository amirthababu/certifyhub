import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

// Create axios instance
const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Unauthorized - clear token and redirect to login
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  getMe: () => api.get('/auth/me'),
};

// Certificate API
export const certificateAPI = {
  upload: (formData) => api.post('/certificates', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  }),
  getMyCertificates: () => api.get('/certificates/my-certificates'),
  getCertificate: (id) => api.get(`/certificates/${id}`),
  downloadCertificate: (id) => api.get(`/certificates/${id}/download`, { responseType: 'blob' }),
  deleteCertificate: (id) => api.delete(`/certificates/${id}`),
  searchCertificates: (params) => api.get('/certificates/search', { params }),
  getStudentCertificates: (studentId) => api.get(`/certificates/student/${studentId}`),
  verifyCertificate: (id) => api.put(`/certificates/${id}/verify`),
};

// Admin API
export const adminAPI = {
  getStats: () => api.get('/admin/stats'),
  getPendingApprovals: () => api.get('/admin/pending'),
  approveUser: (userId) => api.put(`/admin/approve/${userId}`),
  rejectUser: (userId) => api.delete(`/admin/reject/${userId}`),
  getAllUsers: (params) => api.get('/admin/users', { params }),
  deleteUser: (userId) => api.delete(`/admin/users/${userId}`),
  getAllCertificates: (params) => api.get('/admin/certificates', { params }),
  getStudents: () => api.get('/admin/students'),
};

// ML API
export const mlAPI = {
  getGrowthAnalysis: (studentId) => api.get('/ml/analysis', { params: { studentId } }),
  getGrowthChart: (studentId) => api.get('/ml/growth-chart', { params: { studentId } }),
  getPeerComparison: () => api.get('/ml/peer-comparison'),
  getSkillDistribution: (studentId) => api.get('/ml/skill-distribution', { params: { studentId } }),
};

// Notification API
export const notificationAPI = {
  getNotifications: () => api.get('/notifications'),
  markAsRead: (notificationId) => api.put(`/notifications/${notificationId}/read`),
  markAllAsRead: () => api.put('/notifications/read-all'),
  deleteNotification: (notificationId) => api.delete(`/notifications/${notificationId}`),
  clearAll: () => api.delete('/notifications/clear-all'),
};

export default api;
