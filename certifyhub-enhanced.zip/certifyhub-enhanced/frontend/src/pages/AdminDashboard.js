import React, { useState, useEffect } from 'react';
import { adminAPI, certificateAPI } from '../services/api';
import { formatDate, getErrorMessage } from '../utils/helpers';
import CertificateCard from '../components/CertificateCard';

/* ─────── tiny modal wrapper ─────── */
const Modal = ({ title, onClose, children }) => (
  <div style={ms.overlay} onClick={e=>e.target===e.currentTarget&&onClose()}>
    <div style={ms.box}>
      <div style={ms.header}>
        <h3 style={ms.hTitle}>{title}</h3>
        <button style={ms.closeBtn} onClick={onClose}>✕</button>
      </div>
      <div style={ms.body}>{children}</div>
    </div>
  </div>
);
const ms = {
  overlay:  { position:'fixed',inset:0,background:'rgba(0,0,0,0.45)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:1000,padding:'1rem' },
  box:      { background:'#fff',borderRadius:18,width:'100%',maxWidth:700,maxHeight:'90vh',display:'flex',flexDirection:'column',boxShadow:'0 20px 60px rgba(0,0,0,0.2)' },
  header:   { display:'flex',alignItems:'center',justifyContent:'space-between',padding:'1.25rem 1.5rem',borderBottom:'1px solid #f1f5f9' },
  hTitle:   { fontWeight:800,fontSize:'1.1rem',color:'#111827',margin:0 },
  closeBtn: { background:'#f1f5f9',border:'none',borderRadius:8,padding:'0.4rem 0.7rem',cursor:'pointer',fontSize:'0.9rem',color:'#374151',fontWeight:700 },
  body:     { padding:'1.5rem',overflowY:'auto',flex:1 },
};

const AdminDashboard = () => {
  const [activeTab,        setActiveTab]        = useState('dashboard');
  const [stats,            setStats]            = useState(null);
  const [pendingUsers,     setPendingUsers]      = useState([]);
  const [allUsers,         setAllUsers]         = useState([]);
  const [allCertificates,  setAllCertificates]  = useState([]);
  const [loading,          setLoading]          = useState(false);
  const [error,            setError]            = useState('');
  const [userFilter,       setUserFilter]       = useState('all');

  // Modal state
  const [modal, setModal] = useState(null); // { type: 'students'|'teachers'|'pending'|'certificates'|'activity', data: any }

  useEffect(() => {
    if (activeTab==='dashboard')    fetchDashboardStats();
    else if (activeTab==='approvals')    fetchPendingApprovals();
    else if (activeTab==='users')        fetchAllUsers();
    else if (activeTab==='certificates') fetchAllCertificates();
  }, [activeTab]); // eslint-disable-line

  useEffect(() => {
    if (activeTab==='users') fetchAllUsers();
  }, [userFilter]); // eslint-disable-line

  const fetchDashboardStats    = async () => { setLoading(true); try { const r=await adminAPI.getDashboardStats(); setStats(r.data); } catch(e){setError(getErrorMessage(e));} finally{setLoading(false);} };
  const fetchPendingApprovals  = async () => { setLoading(true); try { const r=await adminAPI.getPendingApprovals(); setPendingUsers(r.data.pendingUsers); } catch(e){setError(getErrorMessage(e));} finally{setLoading(false);} };
  const fetchAllUsers          = async () => { setLoading(true); try { const r=await adminAPI.getUsers({ role: userFilter==='all'?'':userFilter }); setAllUsers(r.data.users); } catch(e){setError(getErrorMessage(e));} finally{setLoading(false);} };
  const fetchAllCertificates   = async () => { setLoading(true); try { const r=await certificateAPI.getAllCertificates(); setAllCertificates(r.data.certificates); } catch(e){setError(getErrorMessage(e));} finally{setLoading(false);} };

  const handleApprove = async (userId) => { try { await adminAPI.approveUser(userId); setPendingUsers(p=>p.filter(u=>u._id!==userId)); fetchDashboardStats(); } catch(e){alert(getErrorMessage(e));} };
  const handleReject  = async (userId) => { if(!window.confirm('Reject this user?')) return; try { await adminAPI.rejectUser(userId); setPendingUsers(p=>p.filter(u=>u._id!==userId)); fetchDashboardStats(); } catch(e){alert(getErrorMessage(e));} };
  const handleDeleteUser = async (userId) => { if(!window.confirm('Delete this user? This cannot be undone.')) return; try { await adminAPI.deleteUser(userId); setAllUsers(p=>p.filter(u=>u._id!==userId)); } catch(e){alert(getErrorMessage(e));} };
  const handleDownloadCert = async (certId) => { try { const r=await certificateAPI.download(certId); const url=window.URL.createObjectURL(new Blob([r.data])); const a=document.createElement('a'); a.href=url; a.download=`cert-${certId}.pdf`; a.click(); } catch(e){alert(getErrorMessage(e));} };
  const handleDeleteCert   = async (certId) => { try { await certificateAPI.delete(certId); setAllCertificates(p=>p.filter(c=>c._id!==certId)); } catch(e){alert(getErrorMessage(e));} };
  const handleVerifyCert   = async (certId) => { try { await certificateAPI.verify(certId); setAllCertificates(p=>p.map(c=>c._id===certId?{...c,verificationStatus:'verified',verifiedAt:new Date()}:c)); alert('Certificate verified!'); } catch(e){alert(getErrorMessage(e));} };

  // Open modal for a dashboard card click
  const openCardModal = async (type) => {
    if (type==='students') {
      try { const r=await adminAPI.getUsers({role:'student'}); setModal({type:'students',data:r.data.users}); } catch{}
    } else if (type==='teachers') {
      try { const r=await adminAPI.getUsers({role:'teacher'}); setModal({type:'teachers',data:r.data.users}); } catch{}
    } else if (type==='pending') {
      try { const r=await adminAPI.getPendingApprovals(); setModal({type:'pending',data:r.data.pendingUsers}); } catch{}
    } else if (type==='certificates') {
      try { const r=await certificateAPI.getAllCertificates(); setModal({type:'certificates',data:r.data.certificates}); } catch{}
    }
  };

  const openActivityModal = (activity) => setModal({type:'activity',data:activity});

  const statCards = stats ? [
    { label:'Total Students',    val:stats.totalStudents,    color:'#4f46e5', bg:'#eef2ff', icon:'👨‍🎓', type:'students',     trend:'+12% this month' },
    { label:'Total Teachers',    val:stats.totalTeachers,    color:'#059669', bg:'#ecfdf5', icon:'👩‍🏫', type:'teachers',     trend:'Active faculty' },
    { label:'Pending Approvals', val:stats.pendingApprovals, color:'#d97706', bg:'#fffbeb', icon:'⏳', type:'pending',      trend:'Needs attention' },
    { label:'Total Certificates',val:stats.totalCertificates,color:'#7c3aed', bg:'#f5f3ff', icon:'🏆', type:'certificates', trend:'All time' },
  ] : [];

  const tabs = [
    { id:'dashboard',    label:'Dashboard',        icon:'📊' },
    { id:'approvals',    label:'Pending Approvals', icon:'⏳', badge: stats?.pendingApprovals },
    { id:'users',        label:'Manage Users',      icon:'👥' },
    { id:'certificates', label:'All Certificates',  icon:'🏆' },
  ];

  return (
    <div style={a.root}>
      {/* Sidebar */}
      <div style={a.sidebar}>
        <div style={a.sideTop}>
          <div style={a.brand}><span style={a.brandIcon}>CH</span><span style={a.brandText}>CertifyHub</span></div>
          <p style={a.sideRole}>Admin Panel</p>
        </div>
        <nav style={a.nav}>
          {tabs.map(t=>(
            <button key={t.id} style={{...a.navBtn,...(activeTab===t.id?a.navBtnActive:{})}} onClick={()=>setActiveTab(t.id)}>
              <span style={a.navIcon}>{t.icon}</span>
              <span style={a.navLabel}>{t.label}</span>
              {t.badge>0&&<span style={a.navBadge}>{t.badge}</span>}
            </button>
          ))}
        </nav>
      </div>

      {/* Main */}
      <div style={a.main}>
        {/* Topbar */}
        <div style={a.topbar}>
          <div>
            <h1 style={a.pageTitle}>{tabs.find(t=>t.id===activeTab)?.label}</h1>
            <p style={a.pageSub}>
              {activeTab==='dashboard'  && 'Overview of your platform activity'}
              {activeTab==='approvals'  && 'Review and approve new registrations'}
              {activeTab==='users'      && 'Manage students and teachers'}
              {activeTab==='certificates'&&'View all uploaded certificates'}
            </p>
          </div>
          <div style={a.topbarRight}>
            <div style={a.avatar}>A</div>
          </div>
        </div>

        {/* Content */}
        <div style={a.content}>
          {error&&<div style={a.errorBox}>{error}</div>}
          {loading&&(
            <div style={a.loadingBox}>
              <div style={a.spinner}/>
              <p style={{color:'#6b7280',marginTop:'1rem'}}>Loading...</p>
            </div>
          )}

          {/* ─── DASHBOARD TAB ─── */}
          {!loading && activeTab==='dashboard' && stats && (
            <>
              {/* Stat cards — clickable */}
              <div style={a.cardsGrid}>
                {statCards.map(c=>(
                  <button key={c.label} style={{...a.statCard,background:c.bg,border:`1.5px solid ${c.color}22`}}
                    onClick={()=>openCardModal(c.type)}
                    title={`Click to view all ${c.label}`}>
                    <div style={a.statTop}>
                      <span style={{...a.statIcon,background:c.color+'22',color:c.color}}>{c.icon}</span>
                      <span style={a.clickHint}>View →</span>
                    </div>
                    <div style={{...a.statVal,color:c.color}}>{c.val}</div>
                    <div style={a.statLabel}>{c.label}</div>
                    <div style={{...a.statTrend,color:c.color+'aa'}}>{c.trend}</div>
                  </button>
                ))}
              </div>

              {/* Recent Activity — clickable rows */}
              <div style={a.activityCard}>
                <div style={a.activityHeader}>
                  <h3 style={a.activityTitle}>Recent Activity</h3>
                  <span style={a.activitySub}>Click any row to view details</span>
                </div>
                <div style={a.activityList}>
                  {stats.recentActivity&&stats.recentActivity.length>0 ? (
                    stats.recentActivity.map((act,i)=>(
                      <button key={i} style={a.activityRow} onClick={()=>openActivityModal(act)}>
                        <div style={a.actDot(act.isApproved)}/>
                        <div style={a.actAvatar}>{act.name[0].toUpperCase()}</div>
                        <div style={a.actBody}>
                          <div style={a.actName}>{act.name}</div>
                          <div style={a.actMeta}>{act.role} • {act.department||act.subject||'—'}</div>
                        </div>
                        <div style={a.actRight}>
                          <span style={a.actStatus(act.isApproved)}>{act.isApproved?'✅ Approved':'⏳ Pending'}</span>
                          <span style={a.actDate}>{formatDate(act.registeredAt)}</span>
                        </div>
                        <span style={a.actArrow}>›</span>
                      </button>
                    ))
                  ) : (
                    <p style={{textAlign:'center',color:'#9ca3af',padding:'2rem'}}>No recent activity</p>
                  )}
                </div>
              </div>
            </>
          )}

          {/* ─── APPROVALS TAB ─── */}
          {!loading && activeTab==='approvals' && (
            <div style={a.approvalGrid}>
              {pendingUsers.length===0 ? (
                <div style={a.emptyState}>
                  <div style={a.emptyIcon}>✅</div>
                  <h3 style={a.emptyTitle}>All caught up!</h3>
                  <p style={a.emptySub}>No pending approvals right now.</p>
                </div>
              ) : pendingUsers.map(user=>(
                <div key={user._id} style={a.userCard}>
                  <div style={a.ucTop}>
                    <div style={a.ucAvatar}>{user.name[0].toUpperCase()}</div>
                    <div>
                      <div style={a.ucName}>{user.name}</div>
                      <div style={a.ucEmail}>{user.email}</div>
                    </div>
                    <span style={a.rolePill(user.role)}>{user.role}</span>
                  </div>
                  <div style={a.ucDetails}>
                    {user.rollNumber&&<span style={a.ucTag}>🎓 {user.rollNumber}</span>}
                    {user.department&&<span style={a.ucTag}>🏫 {user.department}</span>}
                    {user.subject&&<span style={a.ucTag}>📚 {user.subject}</span>}
                  </div>
                  <div style={a.ucDate}>Registered {formatDate(user.registeredAt)}</div>
                  <div style={a.ucBtns}>
                    <button style={a.approveBtn} onClick={()=>handleApprove(user._id)}>✓ Approve</button>
                    <button style={a.rejectBtn}  onClick={()=>handleReject(user._id)}>✕ Reject</button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* ─── USERS TAB ─── */}
          {!loading && activeTab==='users' && (
            <>
              <div style={a.toolbar}>
                {['all','student','teacher'].map(f=>(
                  <button key={f} style={{...a.filterBtn,...(userFilter===f?a.filterBtnActive:{})}} onClick={()=>setUserFilter(f)}>
                    {f==='all'?'All Users':f==='student'?'Students':'Teachers'}
                  </button>
                ))}
              </div>
              {allUsers.length===0 ? (
                <p style={{textAlign:'center',color:'#9ca3af',padding:'3rem'}}>No users found</p>
              ) : (
                <div style={a.tableWrap}>
                  <table style={a.table}>
                    <thead><tr style={a.thead}>
                      <th style={a.th}>User</th>
                      <th style={a.th}>Role</th>
                      <th style={a.th}>Details</th>
                      <th style={a.th}>Certificates</th>
                      <th style={a.th}>Status</th>
                      <th style={a.th}>Actions</th>
                    </tr></thead>
                    <tbody>
                      {allUsers.map(u=>(
                        <tr key={u._id} style={a.tr}>
                          <td style={a.td}>
                            <div style={{display:'flex',alignItems:'center',gap:'0.75rem'}}>
                              <div style={a.tableAvatar}>{u.name[0].toUpperCase()}</div>
                              <div><div style={{fontWeight:600,color:'#111827'}}>{u.name}</div><div style={{fontSize:'0.78rem',color:'#6b7280'}}>{u.email}</div></div>
                            </div>
                          </td>
                          <td style={a.td}><span style={a.rolePill(u.role)}>{u.role}</span></td>
                          <td style={a.td}><div style={{fontSize:'0.82rem',color:'#374151'}}>
                            {u.rollNumber&&<div>📋 {u.rollNumber}</div>}
                            {u.department&&<div>🏫 {u.department}</div>}
                            {u.subject&&<div>📚 {u.subject}</div>}
                          </div></td>
                          <td style={a.td}><span style={a.certBadge}>{u.certificateCount||0}</span></td>
                          <td style={a.td}><span style={a.statusPill(u.isApproved)}>{u.isApproved?'Active':'Pending'}</span></td>
                          <td style={a.td}><button style={a.delBtn} onClick={()=>handleDeleteUser(u._id)}>Delete</button></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          )}

          {/* ─── CERTIFICATES TAB ─── */}
          {!loading && activeTab==='certificates' && (
            <>
              {allCertificates.length===0 ? (
                <div style={a.emptyState}><div style={a.emptyIcon}>🏆</div><h3 style={a.emptyTitle}>No certificates yet</h3></div>
              ) : (
                <div style={a.certsGrid}>
                  {allCertificates.map(cert=>(
                    <CertificateCard key={cert._id} certificate={cert} showStudent={true} userRole="admin"
                      onDownload={handleDownloadCert} onDelete={handleDeleteCert} onVerify={handleVerifyCert}/>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* ─── MODALS ─── */}
      {modal && (
        <Modal title={
          modal.type==='students'    ? `All Students (${modal.data.length})` :
          modal.type==='teachers'    ? `All Teachers (${modal.data.length})` :
          modal.type==='pending'     ? `Pending Approvals (${modal.data.length})` :
          modal.type==='certificates'? `All Certificates (${modal.data.length})` :
          modal.type==='activity'    ? `User Details: ${modal.data.name}` : 'Details'
        } onClose={()=>setModal(null)}>
          {/* Students / Teachers list modal */}
          {(modal.type==='students'||modal.type==='teachers') && (
            <div style={{display:'flex',flexDirection:'column',gap:'0.65rem'}}>
              {modal.data.length===0&&<p style={{color:'#9ca3af',textAlign:'center',padding:'2rem'}}>No users found.</p>}
              {modal.data.map(u=>(
                <div key={u._id} style={mod.userRow}>
                  <div style={mod.uAvatar}>{u.name[0].toUpperCase()}</div>
                  <div style={{flex:1}}>
                    <div style={{fontWeight:700,color:'#111827'}}>{u.name}</div>
                    <div style={{fontSize:'0.8rem',color:'#6b7280'}}>{u.email}</div>
                    <div style={{fontSize:'0.78rem',color:'#9ca3af',marginTop:'0.15rem'}}>
                      {u.rollNumber&&<span>📋 {u.rollNumber} · </span>}
                      {u.department&&<span>🏫 {u.department}</span>}
                      {u.subject&&<span>📚 {u.subject}</span>}
                      {u.areasOfInterest&&u.areasOfInterest.length>0&&<span> · 🎯 {u.areasOfInterest.join(', ')}</span>}
                    </div>
                  </div>
                  <div style={{textAlign:'right'}}>
                    <div><span style={a.statusPill(u.isApproved)}>{u.isApproved?'Active':'Pending'}</span></div>
                    <div style={{fontSize:'0.77rem',color:'#9ca3af',marginTop:'0.25rem'}}>{u.certificateCount||0} certs</div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Pending approvals modal */}
          {modal.type==='pending' && (
            <div style={{display:'flex',flexDirection:'column',gap:'0.75rem'}}>
              {modal.data.length===0&&<p style={{color:'#9ca3af',textAlign:'center',padding:'2rem'}}>No pending approvals.</p>}
              {modal.data.map(u=>(
                <div key={u._id} style={mod.pendRow}>
                  <div style={{display:'flex',alignItems:'center',gap:'0.75rem',flex:1}}>
                    <div style={mod.uAvatar}>{u.name[0].toUpperCase()}</div>
                    <div>
                      <div style={{fontWeight:700}}>{u.name} <span style={a.rolePill(u.role)}>{u.role}</span></div>
                      <div style={{fontSize:'0.8rem',color:'#6b7280'}}>{u.email}</div>
                      {u.rollNumber&&<div style={{fontSize:'0.77rem',color:'#9ca3af'}}>📋 {u.rollNumber} · 🏫 {u.department}</div>}
                    </div>
                  </div>
                  <div style={{display:'flex',gap:'0.5rem'}}>
                    <button style={a.approveBtn} onClick={async()=>{await handleApprove(u._id);setModal(m=>({...m,data:m.data.filter(x=>x._id!==u._id)}));}}>✓ Approve</button>
                    <button style={a.rejectBtn}  onClick={async()=>{if(!window.confirm('Reject?'))return;await handleReject(u._id);setModal(m=>({...m,data:m.data.filter(x=>x._id!==u._id)}));}}>✕</button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Certificates modal */}
          {modal.type==='certificates' && (
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'0.75rem'}}>
              {modal.data.length===0&&<p style={{color:'#9ca3af',textAlign:'center',gridColumn:'span 2',padding:'2rem'}}>No certificates.</p>}
              {modal.data.map(cert=>(
                <CertificateCard key={cert._id} certificate={cert} showStudent={true} userRole="admin"
                  onDownload={handleDownloadCert} onDelete={handleDeleteCert} onVerify={handleVerifyCert}/>
              ))}
            </div>
          )}

          {/* Activity detail modal */}
          {modal.type==='activity' && (
            <div style={{display:'flex',flexDirection:'column',gap:'1rem'}}>
              <div style={mod.detailGrid}>
                {[
                  ['Name',         modal.data.name],
                  ['Role',         modal.data.role],
                  ['Status',       modal.data.isApproved?'✅ Approved':'⏳ Pending Approval'],
                  ['Department',   modal.data.department||modal.data.subject||'—'],
                  ['Roll Number',  modal.data.rollNumber||'—'],
                  ['Email',        modal.data.email||'—'],
                  ['Registered',   formatDate(modal.data.registeredAt)],
                  ['Certificates', modal.data.certificateCount||0],
                ].map(([k,v])=>(
                  <div key={k} style={mod.detailItem}>
                    <div style={mod.detailKey}>{k}</div>
                    <div style={mod.detailVal}>{v}</div>
                  </div>
                ))}
              </div>
              {modal.data.areasOfInterest&&modal.data.areasOfInterest.length>0&&(
                <div>
                  <div style={{...mod.detailKey,marginBottom:'0.5rem'}}>Areas of Interest</div>
                  <div style={{display:'flex',gap:'0.4rem',flexWrap:'wrap'}}>
                    {modal.data.areasOfInterest.map(i=>(
                      <span key={i} style={mod.interestTag}>{i}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </Modal>
      )}
    </div>
  );
};

/* ─── Admin styles ─── */
const a = {
  root:        { display:'flex',minHeight:'100vh',background:'#f8fafc',fontFamily:"'Segoe UI','DM Sans',sans-serif" },
  sidebar:     { width:240,flexShrink:0,background:'linear-gradient(180deg,#1e1b4b 0%,#312e81 100%)',display:'flex',flexDirection:'column',padding:'1.5rem 1rem' },
  sideTop:     { marginBottom:'2rem' },
  brand:       { display:'flex',alignItems:'center',gap:'0.65rem',marginBottom:'0.35rem' },
  brandIcon:   { width:34,height:34,borderRadius:9,background:'rgba(255,255,255,0.15)',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:800,fontSize:'0.8rem',color:'#fff' },
  brandText:   { fontWeight:700,fontSize:'1.05rem',color:'#fff',letterSpacing:'-0.01em' },
  sideRole:    { fontSize:'0.75rem',color:'rgba(255,255,255,0.45)',paddingLeft:'0.25rem' },
  nav:         { display:'flex',flexDirection:'column',gap:'0.3rem' },
  navBtn:      { display:'flex',alignItems:'center',gap:'0.65rem',padding:'0.7rem 0.9rem',borderRadius:10,border:'none',background:'transparent',color:'rgba(255,255,255,0.65)',cursor:'pointer',fontSize:'0.88rem',fontWeight:500,textAlign:'left',position:'relative' },
  navBtnActive:{ background:'rgba(255,255,255,0.12)',color:'#fff',fontWeight:700 },
  navIcon:     { fontSize:'1rem',width:20,textAlign:'center' },
  navLabel:    { flex:1 },
  navBadge:    { background:'#ef4444',color:'#fff',borderRadius:20,padding:'0.1rem 0.45rem',fontSize:'0.72rem',fontWeight:700 },
  main:        { flex:1,display:'flex',flexDirection:'column',overflow:'hidden' },
  topbar:      { background:'#fff',borderBottom:'1px solid #f1f5f9',padding:'1.1rem 2rem',display:'flex',alignItems:'center',justifyContent:'space-between' },
  pageTitle:   { fontSize:'1.4rem',fontWeight:800,color:'#111827',margin:0 },
  pageSub:     { fontSize:'0.82rem',color:'#9ca3af',marginTop:'0.1rem' },
  topbarRight: { display:'flex',alignItems:'center',gap:'1rem' },
  avatar:      { width:38,height:38,borderRadius:'50%',background:'linear-gradient(135deg,#4f46e5,#7c3aed)',color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:700 },
  content:     { flex:1,overflowY:'auto',padding:'1.75rem 2rem' },
  errorBox:    { background:'#fef2f2',border:'1px solid #fca5a5',color:'#b91c1c',padding:'0.75rem 1rem',borderRadius:10,marginBottom:'1rem' },
  loadingBox:  { display:'flex',flexDirection:'column',alignItems:'center',padding:'4rem' },
  spinner:     { width:40,height:40,borderRadius:'50%',border:'3px solid #e5e7eb',borderTopColor:'#4f46e5',animation:'spin 0.8s linear infinite' },
  cardsGrid:   { display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))',gap:'1rem',marginBottom:'1.5rem' },
  statCard:    { borderRadius:16,padding:'1.25rem',cursor:'pointer',textAlign:'left',border:'1.5px solid #e5e7eb',transition:'transform 0.15s,box-shadow 0.15s' },
  statTop:     { display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'0.75rem' },
  statIcon:    { width:42,height:42,borderRadius:12,display:'flex',alignItems:'center',justifyContent:'center',fontSize:'1.2rem' },
  clickHint:   { fontSize:'0.75rem',color:'#9ca3af',fontWeight:600 },
  statVal:     { fontSize:'2.2rem',fontWeight:800,letterSpacing:'-0.02em',lineHeight:1 },
  statLabel:   { fontSize:'0.82rem',color:'#374151',fontWeight:600,marginTop:'0.35rem' },
  statTrend:   { fontSize:'0.75rem',marginTop:'0.25rem' },
  activityCard:{ background:'#fff',borderRadius:16,border:'1px solid #f1f5f9',overflow:'hidden' },
  activityHeader:{ display:'flex',alignItems:'center',justifyContent:'space-between',padding:'1.1rem 1.5rem',borderBottom:'1px solid #f1f5f9' },
  activityTitle:{ fontWeight:800,color:'#111827',fontSize:'1rem',margin:0 },
  activitySub:  { fontSize:'0.78rem',color:'#9ca3af' },
  activityList: { display:'flex',flexDirection:'column' },
  activityRow:  { display:'flex',alignItems:'center',gap:'0.85rem',padding:'0.85rem 1.5rem',background:'transparent',border:'none',borderBottom:'1px solid #f8fafc',cursor:'pointer',textAlign:'left',transition:'background 0.15s' },
  actDot:       (ok)=>({ width:8,height:8,borderRadius:'50%',background:ok?'#10b981':'#f59e0b',flexShrink:0 }),
  actAvatar:    { width:36,height:36,borderRadius:'50%',background:'linear-gradient(135deg,#6366f1,#8b5cf6)',color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:700,fontSize:'0.9rem',flexShrink:0 },
  actBody:      { flex:1 },
  actName:      { fontWeight:600,color:'#111827',fontSize:'0.9rem' },
  actMeta:      { fontSize:'0.78rem',color:'#6b7280' },
  actRight:     { display:'flex',flexDirection:'column',alignItems:'flex-end',gap:'0.2rem' },
  actStatus:    (ok)=>({ fontSize:'0.75rem',fontWeight:700,color:ok?'#10b981':'#f59e0b' }),
  actDate:      { fontSize:'0.74rem',color:'#9ca3af' },
  actArrow:     { color:'#d1d5db',fontSize:'1.2rem',fontWeight:300 },
  approvalGrid: { display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(300px,1fr))',gap:'1rem' },
  userCard:     { background:'#fff',borderRadius:16,border:'1px solid #f1f5f9',padding:'1.25rem',boxShadow:'0 1px 4px rgba(0,0,0,0.05)' },
  ucTop:        { display:'flex',alignItems:'center',gap:'0.75rem',marginBottom:'0.85rem' },
  ucAvatar:     { width:44,height:44,borderRadius:'50%',background:'linear-gradient(135deg,#4f46e5,#7c3aed)',color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:700,fontSize:'1.1rem',flexShrink:0 },
  ucName:       { fontWeight:700,color:'#111827' },
  ucEmail:      { fontSize:'0.8rem',color:'#6b7280' },
  ucDetails:    { display:'flex',flexWrap:'wrap',gap:'0.4rem',marginBottom:'0.65rem' },
  ucTag:        { fontSize:'0.78rem',background:'#f3f4f6',color:'#374151',borderRadius:6,padding:'0.25rem 0.6rem' },
  ucDate:       { fontSize:'0.77rem',color:'#9ca3af',marginBottom:'0.85rem' },
  ucBtns:       { display:'flex',gap:'0.5rem' },
  approveBtn:   { flex:1,background:'#ecfdf5',color:'#059669',border:'1px solid #6ee7b7',borderRadius:9,padding:'0.55rem',fontWeight:700,cursor:'pointer',fontSize:'0.85rem' },
  rejectBtn:    { flex:1,background:'#fef2f2',color:'#dc2626',border:'1px solid #fca5a5',borderRadius:9,padding:'0.55rem',fontWeight:700,cursor:'pointer',fontSize:'0.85rem' },
  toolbar:      { display:'flex',gap:'0.5rem',marginBottom:'1rem' },
  filterBtn:    { padding:'0.5rem 1.1rem',borderRadius:20,border:'1.5px solid #e5e7eb',background:'#fff',color:'#374151',cursor:'pointer',fontWeight:600,fontSize:'0.85rem' },
  filterBtnActive:{ background:'#4f46e5',color:'#fff',border:'1.5px solid #4f46e5' },
  tableWrap:    { background:'#fff',borderRadius:14,border:'1px solid #f1f5f9',overflow:'hidden' },
  table:        { width:'100%',borderCollapse:'collapse' },
  thead:        { background:'#f8fafc' },
  th:           { padding:'0.85rem 1rem',textAlign:'left',fontSize:'0.75rem',fontWeight:700,color:'#6b7280',textTransform:'uppercase',letterSpacing:'0.04em',borderBottom:'1px solid #f1f5f9' },
  tr:           { borderBottom:'1px solid #f8fafc' },
  td:           { padding:'0.85rem 1rem',verticalAlign:'middle' },
  tableAvatar:  { width:34,height:34,borderRadius:'50%',background:'linear-gradient(135deg,#6366f1,#8b5cf6)',color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:700,fontSize:'0.85rem',flexShrink:0 },
  rolePill:     (r)=>({ display:'inline-block',padding:'0.2rem 0.6rem',borderRadius:20,fontSize:'0.73rem',fontWeight:700,background:r==='student'?'#eff6ff':r==='teacher'?'#f0fdf4':'#fef3c7',color:r==='student'?'#1d4ed8':r==='teacher'?'#15803d':'#92400e' }),
  certBadge:    { display:'inline-flex',alignItems:'center',justifyContent:'center',width:28,height:28,borderRadius:'50%',background:'#f3f4f6',fontWeight:700,fontSize:'0.82rem',color:'#374151' },
  statusPill:   (ok)=>({ display:'inline-block',padding:'0.2rem 0.65rem',borderRadius:20,fontSize:'0.73rem',fontWeight:700,background:ok?'#f0fdf4':'#fffbeb',color:ok?'#15803d':'#92400e' }),
  delBtn:       { background:'#fef2f2',color:'#dc2626',border:'1px solid #fca5a5',borderRadius:7,padding:'0.35rem 0.75rem',cursor:'pointer',fontWeight:600,fontSize:'0.8rem' },
  certsGrid:    { display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(300px,1fr))',gap:'1rem' },
  emptyState:   { display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:'4rem',textAlign:'center' },
  emptyIcon:    { fontSize:'3rem',marginBottom:'1rem' },
  emptyTitle:   { fontWeight:700,color:'#374151',fontSize:'1.1rem' },
  emptySub:     { color:'#9ca3af',marginTop:'0.35rem' },
};

const mod = {
  userRow:    { display:'flex',alignItems:'center',gap:'0.75rem',padding:'0.85rem',background:'#f8fafc',borderRadius:12 },
  uAvatar:    { width:42,height:42,borderRadius:'50%',background:'linear-gradient(135deg,#4f46e5,#7c3aed)',color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:700,flexShrink:0 },
  pendRow:    { display:'flex',alignItems:'center',gap:'0.75rem',padding:'0.85rem',background:'#fffbeb',borderRadius:12,border:'1px solid #fde68a' },
  detailGrid: { display:'grid',gridTemplateColumns:'1fr 1fr',gap:'0.75rem' },
  detailItem: { background:'#f8fafc',borderRadius:10,padding:'0.75rem 1rem' },
  detailKey:  { fontSize:'0.75rem',fontWeight:700,color:'#6b7280',textTransform:'uppercase',letterSpacing:'0.04em',marginBottom:'0.25rem' },
  detailVal:  { fontWeight:700,color:'#111827',fontSize:'0.95rem' },
  interestTag:{ background:'#eef2ff',color:'#4f46e5',borderRadius:20,padding:'0.28rem 0.8rem',fontSize:'0.8rem',fontWeight:600 },
};

export default AdminDashboard;
