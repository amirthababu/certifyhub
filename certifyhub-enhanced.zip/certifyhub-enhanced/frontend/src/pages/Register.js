import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const INTEREST_OPTIONS = [
  { id: 'Programming',  icon: '💻', desc: 'Coding & Software Dev' },
  { id: 'AI/ML',        icon: '🤖', desc: 'Machine Learning & AI' },
  { id: 'Frontend',     icon: '🎨', desc: 'UI/UX & Web Design' },
  { id: 'Backend',      icon: '⚙️',  desc: 'Servers & APIs' },
  { id: 'Database',     icon: '🗄️',  desc: 'SQL, NoSQL & Data' },
  { id: 'Cloud',        icon: '☁️',  desc: 'AWS, Azure, GCP' },
  { id: 'Mobile',       icon: '📱', desc: 'iOS & Android Dev' },
  { id: 'Other',        icon: '🔬', desc: 'Other Tech Fields' },
];

const Register = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '', email: '', password: '', confirmPassword: '',
    role: 'student', rollNumber: '', department: '', subject: '',
    areasOfInterest: []
  });
  const [error, setError]     = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const toggleInterest = (id) => {
    setFormData(prev => ({
      ...prev,
      areasOfInterest: prev.areasOfInterest.includes(id)
        ? prev.areasOfInterest.filter(x => x !== id)
        : [...prev.areasOfInterest, id]
    }));
  };

  const handleNext = (e) => {
    e.preventDefault();
    setError('');
    if (formData.password !== formData.confirmPassword) { setError('Passwords do not match'); return; }
    if (formData.role === 'student' && (!formData.rollNumber || !formData.department)) { setError('Roll number and department are required'); return; }
    if (formData.role === 'teacher' && !formData.subject) { setError('Department is required for teachers'); return; }
    if (formData.role === 'student') { setStep(2); }
    else handleFinalSubmit();
  };

  const handleFinalSubmit = async (e) => {
    if (e) e.preventDefault();
    setError(''); setSuccess('');
    if (formData.role === 'student' && formData.areasOfInterest.length === 0) {
      setError('Please select at least one area of interest'); return;
    }
    setLoading(true);
    const result = await register({
      name: formData.name, email: formData.email, password: formData.password,
      role: formData.role,
      rollNumber:      formData.role === 'student' ? formData.rollNumber      : undefined,
      department:      formData.role === 'student' ? formData.department      : undefined,
      subject:         formData.role === 'teacher' ? formData.subject         : undefined,
      areasOfInterest: formData.role === 'student' ? formData.areasOfInterest : undefined,
    });
    if (result.success) { setSuccess(result.message); setTimeout(() => navigate('/login'), 3000); }
    else setError(result.error);
    setLoading(false);
  };

  const s = styles;
  return (
    <div style={s.root}>
      <div style={s.left}>
        <div style={s.brand}><div style={s.logo}>CH</div><span style={s.brandName}>CertifyHub</span></div>
        <div style={s.leftContent}>
          <h1 style={s.tagline}>Build your<br/>achievement<br/>portfolio.</h1>
          <p style={s.taglineSub}>Track certificates, get AI-powered insights, and showcase your skills.</p>
          <div style={s.features}>
            {['🎓 Smart OCR auto-fills your certificates','🤖 AI recommends courses based on your interests','📊 Visual growth analytics','✅ Teacher-verified badges'].map(f=>(
              <div key={f} style={s.featureItem}>{f}</div>
            ))}
          </div>
        </div>
        {formData.role === 'student' && (
          <div style={s.steps}>
            <div style={{...s.stepDot,...(step>=1?s.stepActive:{})}}>1</div>
            <div style={{...s.stepLine,...(step>=2?s.stepLineActive:{})}}/>
            <div style={{...s.stepDot,...(step>=2?s.stepActive:{})}}>2</div>
            <div style={{marginLeft:'0.5rem',fontSize:'0.8rem',opacity:0.7}}>
              {step===1?'Account Details':'Your Interests'}
            </div>
          </div>
        )}
      </div>

      <div style={s.right}>
        <div style={s.card}>
          {formData.role === 'student' && (
            <div style={s.stepBadge}>Step {step} of 2 — {step===1?'Account Details':'Your Interests'}</div>
          )}
          <h2 style={s.cardTitle}>{step===1?'Create Account':'🎯 Pick Your Interests'}</h2>
          <p style={s.cardSub}>{step===1?'Join CertifyHub and start your journey':'Help our AI recommend the best courses for you'}</p>

          {error   && <div style={s.errorBox}>{error}</div>}
          {success && <div style={s.successBox}>{success}</div>}

          {step === 1 && (
            <form onSubmit={handleNext} style={s.form}>
              <div style={s.row}>
                <div style={s.col}>
                  <label style={s.label}>Full Name</label>
                  <input style={s.input} type="text" required placeholder="John Doe"
                    value={formData.name} onChange={e=>setFormData({...formData,name:e.target.value})}/>
                </div>
                <div style={s.col}>
                  <label style={s.label}>Role</label>
                  <select style={s.input} value={formData.role} onChange={e=>setFormData({...formData,role:e.target.value})}>
                    <option value="student">Student</option>
                    <option value="teacher">Teacher</option>
                  </select>
                </div>
              </div>
              <div style={s.full}>
                <label style={s.label}>Email Address</label>
                <input style={s.input} type="email" required placeholder="you@college.edu"
                  value={formData.email} onChange={e=>setFormData({...formData,email:e.target.value})}/>
              </div>
              <div style={s.row}>
                <div style={s.col}>
                  <label style={s.label}>Password</label>
                  <input style={s.input} type="password" required placeholder="Min 6 chars"
                    value={formData.password} onChange={e=>setFormData({...formData,password:e.target.value})}/>
                </div>
                <div style={s.col}>
                  <label style={s.label}>Confirm Password</label>
                  <input style={s.input} type="password" required placeholder="Repeat"
                    value={formData.confirmPassword} onChange={e=>setFormData({...formData,confirmPassword:e.target.value})}/>
                </div>
              </div>
              {formData.role === 'student' && (
                <div style={s.row}>
                  <div style={s.col}>
                    <label style={s.label}>Roll Number</label>
                    <input style={s.input} type="text" required placeholder="e.g. 22IT001"
                      value={formData.rollNumber} onChange={e=>setFormData({...formData,rollNumber:e.target.value})}/>
                  </div>
                  <div style={s.col}>
                    <label style={s.label}>Department</label>
                    <input style={s.input} type="text" required placeholder="e.g. CSE, IT, ECE"
                      value={formData.department} onChange={e=>setFormData({...formData,department:e.target.value})}/>
                  </div>
                </div>
              )}
              {formData.role === 'teacher' && (
                <div style={s.full}>
                  <label style={s.label}>Your Department</label>
                  <input style={s.input} type="text" required placeholder="e.g. CSE, IT, ECE"
                    value={formData.subject} onChange={e=>setFormData({...formData,subject:e.target.value})}/>
                  <p style={s.hint}>You'll view only students from your department.</p>
                </div>
              )}
              <button type="submit" style={s.btn}>
                {formData.role === 'student' ? 'Next: Choose Interests →' : (loading?'Registering…':'Create Account')}
              </button>
            </form>
          )}

          {step === 2 && (
            <form onSubmit={handleFinalSubmit} style={s.form}>
              <p style={{fontSize:'0.85rem',color:'#6b7280',marginBottom:'0.5rem'}}>
                Select <strong>all that apply</strong>. AI will map your skill gaps and suggest courses.
              </p>
              <div style={s.igrid}>
                {INTEREST_OPTIONS.map(opt=>{
                  const sel = formData.areasOfInterest.includes(opt.id);
                  return (
                    <button type="button" key={opt.id} onClick={()=>toggleInterest(opt.id)}
                      style={{...s.chip,...(sel?s.chipSel:{})}}>
                      <span style={{fontSize:'1.3rem'}}>{opt.icon}</span>
                      <span style={{fontSize:'0.88rem',fontWeight:700,color:'#111827'}}>{opt.id}</span>
                      <span style={{fontSize:'0.73rem',color:'#6b7280'}}>{opt.desc}</span>
                      {sel&&<span style={s.checkmark}>✓</span>}
                    </button>
                  );
                })}
              </div>
              <div style={{display:'flex',gap:'0.75rem',marginTop:'0.5rem'}}>
                <button type="button" style={s.btnOut} onClick={()=>setStep(1)}>← Back</button>
                <button type="submit" disabled={loading} style={{...s.btn,flex:1}}>
                  {loading?'Creating Account…':`Register (${formData.areasOfInterest.length} selected)`}
                </button>
              </div>
            </form>
          )}

          <p style={s.link}>
            Already have an account?{' '}
            <Link to="/login" style={{color:'#4f46e5',fontWeight:600,textDecoration:'none'}}>Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

const styles = {
  root:        { display:'flex', minHeight:'100vh', fontFamily:"'Segoe UI', 'DM Sans', sans-serif" },
  left:        { width:360, flexShrink:0, background:'linear-gradient(160deg,#1e1b4b 0%,#312e81 55%,#4338ca 100%)', color:'#fff', display:'flex', flexDirection:'column', padding:'2.5rem', overflow:'hidden' },
  brand:       { display:'flex', alignItems:'center', gap:'0.75rem', marginBottom:'3rem' },
  logo:        { width:38, height:38, borderRadius:10, background:'rgba(255,255,255,0.15)', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:800, fontSize:'0.85rem' },
  brandName:   { fontWeight:700, fontSize:'1.15rem', letterSpacing:'-0.02em' },
  leftContent: { flex:1 },
  tagline:     { fontSize:'2.2rem', fontWeight:800, lineHeight:1.15, letterSpacing:'-0.03em', marginBottom:'1rem' },
  taglineSub:  { fontSize:'0.9rem', opacity:0.7, lineHeight:1.65, marginBottom:'2rem' },
  features:    { display:'flex', flexDirection:'column', gap:'0.6rem' },
  featureItem: { fontSize:'0.84rem', opacity:0.82, padding:'0.45rem 0.7rem', background:'rgba(255,255,255,0.08)', borderRadius:8 },
  steps:       { display:'flex', alignItems:'center', gap:'0.5rem', marginTop:'2.5rem' },
  stepDot:     { width:26, height:26, borderRadius:'50%', background:'rgba(255,255,255,0.18)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'0.78rem', fontWeight:700 },
  stepActive:  { background:'#fff', color:'#4338ca' },
  stepLine:    { flex:1, height:2, background:'rgba(255,255,255,0.2)' },
  stepLineActive:{background:'#fff'},
  right:       { flex:1, display:'flex', alignItems:'center', justifyContent:'center', background:'#f8fafc', padding:'2rem', overflowY:'auto' },
  card:        { width:'100%', maxWidth:540, background:'#fff', borderRadius:20, padding:'2.25rem', boxShadow:'0 4px 30px rgba(0,0,0,0.08)' },
  stepBadge:   { display:'inline-block', fontSize:'0.75rem', fontWeight:600, color:'#4f46e5', background:'#eef2ff', borderRadius:20, padding:'0.28rem 0.8rem', marginBottom:'0.75rem' },
  cardTitle:   { fontSize:'1.65rem', fontWeight:800, color:'#111827', letterSpacing:'-0.02em', marginBottom:'0.25rem' },
  cardSub:     { fontSize:'0.88rem', color:'#6b7280', marginBottom:'1.4rem' },
  errorBox:    { background:'#fef2f2', border:'1px solid #fca5a5', color:'#b91c1c', padding:'0.7rem 1rem', borderRadius:10, marginBottom:'1rem', fontSize:'0.875rem' },
  successBox:  { background:'#f0fdf4', border:'1px solid #86efac', color:'#15803d', padding:'0.7rem 1rem', borderRadius:10, marginBottom:'1rem', fontSize:'0.875rem' },
  form:        { display:'flex', flexDirection:'column', gap:'0.9rem' },
  row:         { display:'grid', gridTemplateColumns:'1fr 1fr', gap:'0.75rem' },
  col:         { display:'flex', flexDirection:'column', gap:'0.3rem' },
  full:        { display:'flex', flexDirection:'column', gap:'0.3rem' },
  label:       { fontSize:'0.75rem', fontWeight:700, color:'#374151', textTransform:'uppercase', letterSpacing:'0.05em' },
  input:       { border:'1.5px solid #e5e7eb', borderRadius:10, padding:'0.62rem 0.85rem', fontSize:'0.91rem', outline:'none', background:'#fafafa', color:'#111827', width:'100%', boxSizing:'border-box' },
  hint:        { fontSize:'0.77rem', color:'#9ca3af', marginTop:'0.2rem' },
  btn:         { background:'linear-gradient(135deg,#4f46e5,#7c3aed)', color:'#fff', border:'none', borderRadius:12, padding:'0.78rem', fontSize:'0.93rem', fontWeight:700, cursor:'pointer', width:'100%' },
  btnOut:      { background:'#f3f4f6', color:'#374151', border:'1.5px solid #e5e7eb', borderRadius:12, padding:'0.78rem 1.1rem', fontSize:'0.9rem', fontWeight:600, cursor:'pointer', whiteSpace:'nowrap' },
  igrid:       { display:'grid', gridTemplateColumns:'1fr 1fr', gap:'0.6rem' },
  chip:        { border:'1.5px solid #e5e7eb', borderRadius:12, padding:'0.8rem 0.9rem', background:'#fafafa', cursor:'pointer', textAlign:'left', position:'relative', display:'flex', flexDirection:'column', gap:'0.12rem', transition:'all 0.15s' },
  chipSel:     { border:'1.5px solid #4f46e5', background:'#eef2ff' },
  checkmark:   { position:'absolute', top:8, right:10, color:'#4f46e5', fontWeight:700, fontSize:'0.9rem' },
  link:        { textAlign:'center', marginTop:'1.25rem', fontSize:'0.86rem', color:'#6b7280' },
};

export default Register;
