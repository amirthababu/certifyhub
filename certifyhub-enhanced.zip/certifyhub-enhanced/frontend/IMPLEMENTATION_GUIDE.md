# Frontend Implementation Guide

## ✅ What's Already Done

### 1. Project Setup
- ✅ package.json with all dependencies
- ✅ Tailwind CSS configuration
- ✅ PostCSS configuration
- ✅ index.html with fonts
- ✅ Global CSS with custom utilities
- ✅ Directory structure

### 2. Utilities
- ✅ API utility (src/utils/api.js) - Complete with all endpoints
- ✅ Socket.io utility (src/utils/socket.js) - Ready for real-time features

## 🏗️ Components to Build

### Priority 1: Authentication (Required First)

#### 1. src/context/AuthContext.jsx
```javascript
// Manage user authentication state
// Features:
// - Login/logout functionality
// - Store user data and token
// - Check authentication status
// - Provide auth state to all components
```

#### 2. src/components/Auth/Login.jsx
```javascript
// Login form
// API: authAPI.login()
// Fields: email, password
// Redirect based on role after login
```

#### 3. src/components/Auth/Register.jsx
```javascript
// Registration form
// API: authAPI.register()
// Fields: name, email, password, role, rollNumber (student), department (student), subject (teacher)
// Show appropriate fields based on selected role
```

#### 4. src/components/Common/PrivateRoute.jsx
```javascript
// Protected route wrapper
// Check if user is authenticated
// Redirect to login if not authenticated
// Check role-based access
```

### Priority 2: Common Components

#### 5. src/components/Common/Navbar.jsx
```javascript
// Navigation bar
// Show different links based on role
// Logout button
// Notification bell icon (for teachers)
```

#### 6. src/components/Common/CertificateCard.jsx
```javascript
// Reusable certificate card component
// Props: certificate data
// Show: title, description, date, verification badge, download/delete buttons
```

### Priority 3: Student Dashboard

#### 7. src/components/Student/Dashboard.jsx
```javascript
// Main student dashboard
// Show: total certificates, upload button, recent certificates
// Navigate to: UploadCertificate, MyCertificates, GrowthAnalysis
```

#### 8. src/components/Student/UploadCertificate.jsx
```javascript
// Certificate upload form
// API: certificateAPI.upload()
// Fields: title, description, issueDate, file, certificateId, issuer, qrCodeData
// File validation: PDF, JPG, PNG, max 10MB
```

#### 9. src/components/Student/MyCertificates.jsx
```javascript
// List of student's certificates
// API: certificateAPI.getMyCertificates()
// Features: view, download, delete
// Use CertificateCard component
```

#### 10. src/components/Student/GrowthAnalysis.jsx
```javascript
// ML growth analysis view
// APIs:
// - mlAPI.getGrowthAnalysis()
// - mlAPI.getGrowthChart()
// - mlAPI.getPeerComparison()
// - mlAPI.getSkillDistribution()
// Use Recharts for visualizations
// Show: scores, predictions, recommendations, charts
```

### Priority 4: Teacher Dashboard

#### 11. src/components/Teacher/Dashboard.jsx
```javascript
// Teacher main dashboard
// Navigate to: StudentList, NotificationBell
```

#### 12. src/components/Teacher/StudentList.jsx
```javascript
// Grid of student cards (60 students layout)
// API: adminAPI.getStudents()
// Click card to view student's certificates
// Show: name, roll number, certificate count
```

#### 13. src/components/Teacher/CertificateView.jsx
```javascript
// View and search student certificates
// APIs:
// - certificateAPI.searchCertificates() with NLP query
// - certificateAPI.getStudentCertificates()
// Features:
// - NLP search bar
// - Year filter dropdown (2024, 2023, 2022...)
// - Verification status filter
// - Download, verify buttons
```

#### 14. src/components/Teacher/NotificationBell.jsx
```javascript
// Notification bell with badge
// APIs:
// - notificationAPI.getNotifications()
// - notificationAPI.markAsRead()
// - notificationAPI.deleteNotification()
// Socket: Listen for 'newCertificate' event
// Show dropdown with notifications
```

### Priority 5: Admin Dashboard

#### 15. src/components/Admin/Dashboard.jsx
```javascript
// Admin main dashboard
// Tabs: Dashboard, Pending Approvals, Manage Users, All Certificates
```

#### 16. src/components/Admin/PendingApprovals.jsx
```javascript
// Pending student and teacher approvals
// API: adminAPI.getPendingApprovals()
// Actions:
// - adminAPI.approveUser()
// - adminAPI.rejectUser()
// Show combined list with user details
```

#### 17. src/components/Admin/ManageUsers.jsx
```javascript
// User management
// API: adminAPI.getAllUsers()
// Features:
// - Filter by role (Student, Teacher, All)
// - Show certificate counts for students
// - Delete user button
```

#### 18. src/components/Admin/AllCertificates.jsx
```javascript
// View all certificates in system
// API: adminAPI.getAllCertificates()
// Features:
// - Filter by student
// - Show student name
// - Download, delete buttons
```

### Priority 6: Main App

#### 19. src/App.jsx
```javascript
// Main app component
// Setup:
// - React Router with routes
// - AuthContext provider
// - Socket connection (for teachers)
// Routes:
// - / -> Redirect to role dashboard or login
// - /login
// - /register
// - /student/* -> Student routes
// - /teacher/* -> Teacher routes
// - /admin/* -> Admin routes
```

#### 20. src/index.jsx
```javascript
// Entry point
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
```

## 🎨 Design Guidelines

### Colors (Already in Tailwind config)
- Primary: Blue (primary-500, primary-600, etc.)
- Accent: Purple (accent-500, accent-600, etc.)
- Success: Green
- Warning: Yellow
- Danger: Red

### Components to Use
- **Buttons**: .btn-primary, .btn-secondary, .btn-danger
- **Inputs**: .input-field
- **Cards**: .card
- **Badges**: .badge-success, .badge-warning, .badge-info, .badge-danger

### Icons
Use Lucide React:
```javascript
import { 
  Upload, Download, Trash2, Search, Bell, 
  User, Award, TrendingUp, BarChart, CheckCircle 
} from 'lucide-react';
```

## 📝 Implementation Tips

### 1. Start with Authentication
Build Login -> Register -> AuthContext -> PrivateRoute first. This is the foundation.

### 2. Use React Hooks
```javascript
import { useState, useEffect, useContext } from 'react';
```

### 3. Error Handling
```javascript
try {
  const response = await certificateAPI.upload(formData);
  // Success
} catch (error) {
  console.error(error);
  // Show error message
}
```

### 4. Loading States
```javascript
const [loading, setLoading] = useState(false);
// Show spinner when loading
```

### 5. Socket Connection (Teachers only)
```javascript
import socketService from '../utils/socket';

useEffect(() => {
  if (user.role === 'teacher') {
    socketService.connect(user.id);
    
    socketService.onNewCertificate((data) => {
      // Update notifications
    });
    
    return () => {
      socketService.disconnect();
    };
  }
}, [user]);
```

### 6. File Upload
```javascript
const handleUpload = async (e) => {
  e.preventDefault();
  
  const formData = new FormData();
  formData.append('certificate', file);
  formData.append('title', title);
  formData.append('description', description);
  formData.append('issueDate', issueDate);
  // ... other fields
  
  const response = await certificateAPI.upload(formData);
};
```

### 7. Chart Visualization (Recharts)
```javascript
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

<LineChart data={chartData}>
  <CartesianGrid strokeDasharray="3 3" />
  <XAxis dataKey="date" />
  <YAxis />
  <Tooltip />
  <Legend />
  <Line type="monotone" dataKey="count" stroke="#2563eb" />
</LineChart>
```

## 🧪 Testing Components

1. **Test Login**: Use admin credentials created via script
2. **Test Register**: Create student and teacher accounts
3. **Test Admin Approval**: Login as admin and approve users
4. **Test Upload**: Login as student and upload a certificate
5. **Test Notifications**: Check if teacher receives notification
6. **Test Search**: Use NLP search with queries like "React course"
7. **Test ML Analysis**: Upload 5+ certificates and view analysis

## 🚀 Development Workflow

1. Start backend: `cd backend && npm run dev`
2. Start frontend: `cd frontend && npm start`
3. Create admin: `cd backend && npm run create-admin`
4. Implement components in order (Auth first)
5. Test each component after implementation
6. Integrate Socket.io for real-time features
7. Add charts and visualizations
8. Polish UI/UX

## 📦 Environment Variables

Create `frontend/.env`:
```env
REACT_APP_API_URL=http://localhost:5000/api
REACT_APP_SOCKET_URL=http://localhost:5000
```

## ✅ Completion Checklist

- [ ] Authentication components (Login, Register, AuthContext)
- [ ] Student dashboard (Dashboard, Upload, Certificates, Analysis)
- [ ] Teacher dashboard (Students, Certificates, Notifications)
- [ ] Admin dashboard (Stats, Approvals, Users, Certificates)
- [ ] Socket.io integration for real-time notifications
- [ ] Charts and visualizations with Recharts
- [ ] Responsive design for mobile
- [ ] Error handling and loading states
- [ ] Form validation
- [ ] File upload with preview
- [ ] Download functionality
- [ ] Search and filter features

## 🎯 Expected Outcome

A fully functional certificate management system where:
- Admins can manage users and moderate content
- Teachers can view students, search certificates, and receive notifications
- Students can upload certificates and view ML-powered growth analysis
- Real-time notifications work across the system
- ML predictions provide career guidance
- NLP search finds relevant certificates

## 🆘 Need Help?

- Backend API reference: `backend/README.md`
- API utilities are ready in: `src/utils/api.js`
- Socket utilities are ready in: `src/utils/socket.js`
- All backend endpoints are documented and working

Good luck building the frontend! 🚀
