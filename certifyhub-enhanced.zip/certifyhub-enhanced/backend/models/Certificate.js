const mongoose = require('mongoose');

const certificateSchema = new mongoose.Schema({
  student:  { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title:    { type: String, required: true, trim: true },
  description: { type: String, required: true },

  issueDate: { type: Date, required: true },

  /* Duration fields — for accurate monthsActive in ML */
  certificateType:    { type: String, enum: ['course','internship','other'], default: 'course' },
  courseStartDate:    { type: Date },
  courseEndDate:      { type: Date },
  internshipStartDate:{ type: Date },
  internshipEndDate:  { type: Date },

  /* File */
  fileName: { type: String, required: true },
  filePath: { type: String, required: true },
  fileType: { type: String, required: true },

  /* Verification */
  certificateId:    { type: String, trim: true, default: '' },
  issuer:           { type: String, enum: ['Coursera','Udemy','LinkedIn','Google','Microsoft','AWS','Other',''], default: '' },
  qrCodeData:       { type: String, trim: true, default: '' },
  verificationStatus: { type: String, enum: ['verified','unverified','pending'], default: 'unverified' },
  verificationMethod: { type: String, enum: ['qr_code','certificate_id','ocr_qr','ocr_certificate_id','manual','none'], default: 'none' },
  verifiedBy:   { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  verifiedAt:   { type: Date },
  ocrExtracted: { type: Boolean, default: false },

  /* NLP */
  category:   { type: String, enum: ['Programming','Backend','Frontend','Database','Cloud','AI/ML','Mobile','Other'], default: 'Other' },
  keywords:   [String],
  skillLevel: { type: String, enum: ['Beginner','Intermediate','Advanced'], default: 'Beginner' },

  uploadedAt: { type: Date, default: Date.now }
}, { timestamps: true });

certificateSchema.index({ student: 1, issueDate: -1 });
certificateSchema.index({ category: 1 });
certificateSchema.index({ verificationStatus: 1 });
certificateSchema.index({ keywords: 1 });

module.exports = mongoose.model('Certificate', certificateSchema);
