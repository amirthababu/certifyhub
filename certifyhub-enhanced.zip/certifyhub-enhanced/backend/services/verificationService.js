/**
 * verificationService.js
 * OCR-powered automatic verification pipeline.
 * All heavy deps (tesseract.js, jimp, jsqr, pdf-parse) are lazy-loaded
 * so the server starts cleanly even before `npm install`.
 */
const axios = require('axios');
const fs    = require('fs');

const ISSUER_VERIFY_URLS = {
  Coursera:  id => `https://www.coursera.org/verify/${id}`,
  Udemy:     id => `https://www.udemy.com/certificate/${id}/`,
  LinkedIn:  id => `https://www.linkedin.com/learning/certificates/${id}`,
  Google:    id => `https://skillshop.credential.net/verify/${id}`,
  Microsoft: id => `https://learn.microsoft.com/api/credentials/share/${id}`,
  AWS:       id => `https://aws.amazon.com/verification/${id}`,
};

const CERT_ID_PATTERNS = {
  Coursera:  /([A-Z0-9]{8,20})/,
  Udemy:     /UC-([A-Za-z0-9\-]{20,40})/,
  LinkedIn:  /([A-Za-z0-9]{30,50})/,
  Google:    /([A-Za-z0-9\-]{16,40})/,
  Microsoft: /([A-Za-z0-9\-]{36})/,
  AWS:       /([A-Z0-9]{12,20})/,
};

async function extractTextFromPDF(filePath) {
  try {
    const pdfParse = require('pdf-parse');
    return (await pdfParse(fs.readFileSync(filePath))).text || '';
  } catch(e) { console.warn('pdf-parse:', e.message); return ''; }
}

async function extractTextFromImage(filePath) {
  try {
    const Tesseract = require('tesseract.js');
    const { data: { text } } = await Tesseract.recognize(filePath, 'eng', { logger: ()=>{} });
    return text || '';
  } catch(e) { console.warn('Tesseract:', e.message); return ''; }
}

async function extractQRFromImage(filePath) {
  try {
    const Jimp = require('jimp');
    const jsQR = require('jsqr');
    const img  = await Jimp.read(filePath);
    const code = jsQR(new Uint8ClampedArray(img.bitmap.data), img.bitmap.width, img.bitmap.height);
    return code ? code.data : null;
  } catch(e) { console.warn('QR scan:', e.message); return null; }
}

function parseCertificateId(ocrText, issuer) {
  if (!ocrText || !issuer) return null;
  const pat = CERT_ID_PATTERNS[issuer];
  if (!pat) return null;
  const m = ocrText.match(pat);
  return m ? (m[1] || m[0]) : null;
}

async function verifyWithIssuerURL(issuer, certId) {
  const build = ISSUER_VERIFY_URLS[issuer];
  if (!build || !certId) return { verified: false, reason: 'No verification URL' };
  const url = build(certId);
  try {
    const r = await axios.head(url, { timeout: 7000, validateStatus: s => s < 500 });
    const ok = r.status >= 200 && r.status < 400;
    return { verified: ok, url, reason: ok ? `Confirmed at ${issuer} (HTTP ${r.status})` : `Not found at ${issuer} (HTTP ${r.status})` };
  } catch(e) {
    return { verified: false, url, reason: `Cannot reach ${issuer}: ${e.message}` };
  }
}

async function autoVerifyCertificate({ filePath, fileType, issuer, certificateId: manualId, qrCodeData: manualQR }) {
  const result = { status:'unverified', method:'none', extractedId:null, extractedQR:null, message:'No verification data extracted', verifiedAt:undefined };
  const ext = (fileType||'').replace('image/','').replace('application/','').toLowerCase();

  let ocrText = '';
  if (ext === 'pdf') ocrText = await extractTextFromPDF(filePath);
  else if (['jpg','jpeg','png'].includes(ext)) ocrText = await extractTextFromImage(filePath);

  let qrData = manualQR || null;
  if (!qrData && ['jpg','jpeg','png'].includes(ext)) {
    qrData = await extractQRFromImage(filePath);
    if (qrData) { result.extractedQR = qrData; result.method = 'ocr_qr'; }
  }

  let certId = manualId || null;
  if (!certId && ocrText && issuer) {
    certId = parseCertificateId(ocrText, issuer);
    if (certId) { result.extractedId = certId; result.method = result.method || 'ocr_certificate_id'; }
  }

  if (issuer && issuer !== 'Other') {
    if (qrData && qrData.startsWith('http')) {
      try {
        const r = await axios.head(qrData, { timeout: 7000, validateStatus: s => s < 500 });
        const ok = r.status >= 200 && r.status < 400;
        result.status = ok ? 'verified' : 'unverified';
        result.verificationUrl = qrData;
        result.message = ok ? `QR URL verified (HTTP ${r.status})` : `QR URL returned HTTP ${r.status}`;
        if (ok) result.verifiedAt = new Date();
      } catch(e) { result.message = `QR URL unreachable: ${e.message}`; }
    } else if (certId) {
      const r = await verifyWithIssuerURL(issuer, certId);
      result.status = r.verified ? 'verified' : 'unverified';
      result.verificationUrl = r.url || null;
      result.message = r.reason;
      if (r.verified) result.verifiedAt = new Date();
    } else {
      result.message = ocrText ? 'Text extracted but no Certificate ID or QR found' : 'Could not extract text from file';
    }
  } else {
    result.message = (certId || qrData) ? 'Data extracted but no supported issuer selected' : 'No verification data found in file';
  }
  return result;
}

function manualVerification(verifiedBy) {
  return { status:'verified', method:'manual', message:'Manually verified by teacher or admin', verifiedAt:new Date(), verifiedBy };
}

function getSupportedIssuers() {
  return ['Coursera','Udemy','LinkedIn','Google','Microsoft','AWS','Other'].map(n => ({ name:n, code:n.toLowerCase() }));
}

module.exports = { autoVerifyCertificate, manualVerification, getSupportedIssuers, extractTextFromImage, extractTextFromPDF, extractQRFromImage, parseCertificateId };
