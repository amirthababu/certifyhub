# CertifyHub Backend

AI-Powered Certificate Management System with Machine Learning Growth Analysis

## 🚀 Features

### Authentication & Authorization
- JWT-based authentication
- Bcrypt password hashing (10 rounds)
- Role-based access control (Admin, Teacher, Student)
- Admin approval system for students and teachers

### Certificate Management
- Upload certificates (PDF, JPG, PNG)
- Automatic NLP-powered categorization
- Certificate verification with external APIs (simulated)
- Download and delete certificates
- View verification status and badges

### NLP Search System
- Natural.js + Compromise.js integration
- Keyword extraction and categorization
- Intelligent search with relevance scoring
- Search suggestions

### Machine Learning Growth Analysis
- Random Forest algorithm with 5 decision trees
- 11 extracted features for analysis
- Career readiness score (0-100)
- Skill level predictions
- Career role predictions with confidence percentages
- Personalized AI recommendations
- Growth visualization charts

### Real-Time Notifications
- Socket.io integration
- Real-time certificate upload notifications
- Notification management (mark as read, delete)
- Browser notifications support

## 📋 Prerequisites

- Node.js (v14 or higher)
- MongoDB (v4.4 or higher)
- npm or yarn

## 🔧 Installation

1. **Clone the repository and navigate to backend:**
   ```bash
   cd certifyhub/backend
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Configure environment variables:**
   Create a `.env` file in the backend directory:
   ```env
   PORT=5000
   MONGODB_URI=mongodb://localhost:27017/certifyhub
   JWT_SECRET=your_super_secret_jwt_key_change_this_in_production
   JWT_EXPIRE=7d
   NODE_ENV=development
   FRONTEND_URL=http://localhost:3000
   ```

4. **Start MongoDB:**
   ```bash
   # On macOS with Homebrew
   brew services start mongodb-community

   # On Ubuntu
   sudo systemctl start mongod

   # Or using Docker
   docker run -d -p 27017:27017 --name mongodb mongo:latest
   ```

5. **Create admin account:**
   ```bash
   npm run create-admin
   ```
   Follow the prompts to create your admin account.

6. **Start the server:**
   ```bash
   # Development mode with nodemon
   npm run dev

   # Production mode
   npm start
   ```

The server will start on `http://localhost:5000`

## 📁 Project Structure

```
backend/
├── config/
│   └── db.js                    # MongoDB connection
├── controllers/
│   ├── authController.js        # Authentication logic
│   ├── certificateController.js # Certificate CRUD & search
│   ├── adminController.js       # Admin operations
│   ├── mlController.js          # ML analysis endpoints
│   └── notificationController.js# Real-time notifications
├── middleware/
│   ├── auth.js                  # JWT & role-based auth
│   └── upload.js                # Multer file upload
├── models/
│   ├── User.js                  # User schema
│   └── Certificate.js           # Certificate schema
├── routes/
│   ├── auth.js                  # Auth routes
│   ├── certificates.js          # Certificate routes
│   ├── admin.js                 # Admin routes
│   ├── ml.js                    # ML routes
│   └── notifications.js         # Notification routes
├── utils/
│   ├── nlpService.js            # NLP search & categorization
│   ├── mlService.js             # Random Forest ML
│   └── verificationService.js   # Certificate verification
├── uploads/
│   └── certificates/            # Uploaded files
├── scripts/
│   └── createAdmin.js           # CLI to create admin
├── server.js                    # Main server file
├── package.json
└── .env
```

## 🛣️ API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user (student/teacher)
- `POST /api/auth/login` - Login user
- `GET /api/auth/me` - Get current user

### Certificates (Students)
- `POST /api/certificates` - Upload certificate
- `GET /api/certificates/my-certificates` - Get own certificates
- `GET /api/certificates/:id` - Get single certificate
- `GET /api/certificates/:id/download` - Download certificate
- `DELETE /api/certificates/:id` - Delete certificate

### Certificates (Teachers/Admin)
- `GET /api/certificates/search` - NLP search with filters
- `GET /api/certificates/suggestions` - Get search suggestions
- `GET /api/certificates/student/:studentId` - Get student certificates
- `PUT /api/certificates/:id/verify` - Manually verify certificate

### Admin
- `GET /api/admin/stats` - Dashboard statistics
- `GET /api/admin/pending` - Pending approvals
- `PUT /api/admin/approve/:userId` - Approve user
- `DELETE /api/admin/reject/:userId` - Reject user
- `GET /api/admin/users` - Get all users
- `DELETE /api/admin/users/:userId` - Delete user
- `GET /api/admin/certificates` - Get all certificates
- `GET /api/admin/students` - Get all students

### ML Analysis
- `GET /api/ml/analysis` - Get growth analysis
- `GET /api/ml/growth-chart` - Get growth chart data
- `GET /api/ml/peer-comparison` - Get peer comparison
- `GET /api/ml/skill-distribution` - Get skill distribution

### Notifications (Teachers)
- `GET /api/notifications` - Get notifications
- `PUT /api/notifications/:notificationId/read` - Mark as read
- `PUT /api/notifications/read-all` - Mark all as read
- `DELETE /api/notifications/:notificationId` - Delete notification
- `DELETE /api/notifications/clear-all` - Clear all

## 🧪 Testing the API

You can test the API using tools like Postman, Thunder Client, or curl.

### Example: Register a student
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john@example.com",
    "password": "password123",
    "role": "student",
    "rollNumber": "CS2024001",
    "department": "CSE"
  }'
```

### Example: Login
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@certifyhub.com",
    "password": "admin123"
  }'
```

## 🔐 Authentication Flow

1. User registers with role (student/teacher)
2. Admin approves the registration
3. User can now login with credentials
4. JWT token is returned upon successful login
5. Include token in Authorization header for protected routes:
   ```
   Authorization: Bearer <your_token_here>
   ```

## 🤖 ML Algorithm Details

### Random Forest Implementation
The ML service uses a simulated Random Forest with 5 decision trees:

#### Decision Tree 1: Certificate Volume (5-25 points)
- Analyzes total certificate count
- Rewards consistent learning

#### Decision Tree 2: Skill Diversity (0-20 points)
- Measures breadth of skills
- Calculates unique categories

#### Decision Tree 3: Learning Progression (0-25 points)
- Tracks beginner → intermediate → advanced trajectory
- Rewards upward progression

#### Decision Tree 4: Growth Rate Consistency (0-15 points)
- Evaluates learning pace
- Identifies consistent learners

#### Decision Tree 5: Specialization Bonuses (0-15 points)
- Rewards full-stack capabilities
- Identifies specialization patterns

### Feature Engineering
11 features extracted from certificates:
- Total certificate count
- Category distribution (7 categories)
- Average time gap between certificates
- Growth rate (certificates per month)
- Diversity score
- Progression score
- Months active

## 🔍 NLP Search Features

- Keyword extraction using Natural.js
- Semantic understanding with Compromise.js
- Automatic categorization into 8 categories:
  - Programming
  - Backend
  - Frontend
  - Database
  - Cloud
  - AI/ML
  - Mobile
  - Other

## 🔌 Socket.io Events

### Client → Server
- `join` - Join user-specific room
- `test` - Test connection

### Server → Client
- `newCertificate` - New certificate uploaded notification
- `testResponse` - Test response

## 📦 Dependencies

### Core
- `express` - Web framework
- `mongoose` - MongoDB ODM
- `jsonwebtoken` - JWT authentication
- `bcryptjs` - Password hashing
- `dotenv` - Environment variables
- `cors` - Cross-origin resource sharing

### File Upload
- `multer` - Multipart form data

### Real-time
- `socket.io` - WebSocket communication

### NLP & ML
- `natural` - Natural language processing
- `compromise` - Text analysis
- `axios` - HTTP client for API calls

## 🛡️ Security Features

- Password hashing with bcrypt (10 rounds)
- JWT token expiration
- Role-based access control
- File type validation
- File size limits (10MB)
- Admin approval system
- Secure file storage

## 🐛 Troubleshooting

### MongoDB Connection Issues
```bash
# Check if MongoDB is running
mongosh

# Start MongoDB service
# macOS
brew services start mongodb-community

# Ubuntu
sudo systemctl start mongod
```

### Port Already in Use
```bash
# Find process using port 5000
lsof -i :5000

# Kill the process
kill -9 <PID>
```

### Module Not Found
```bash
# Clear npm cache and reinstall
rm -rf node_modules package-lock.json
npm install
```

## 📝 License

This project is part of CertifyHub - AI-Powered Certificate Management System.

## 🤝 Support

For issues and questions, please refer to the main project documentation.
