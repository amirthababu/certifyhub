const Certificate = require('../models/Certificate');
const User = require('../models/User');
const mlService = require('../utils/mlService');

// @desc    Get ML growth analysis for student
// @route   GET /api/ml/analysis
// @access  Private (Student - own, Teacher/Admin - any)
exports.getGrowthAnalysis = async (req, res) => {
  try {
    let studentId = req.user.id;

    // Teachers and admins can view any student's analysis
    if ((req.user.role === 'teacher' || req.user.role === 'admin') && req.query.studentId) {
      studentId = req.query.studentId;
    }

    // Get student info
    const student = await User.findById(studentId).select('name rollNumber department');
    
    if (!student) {
      return res.status(404).json({
        success: false,
        message: 'Student not found'
      });
    }

    // Get all certificates for the student
    const certificates = await Certificate.find({ student: studentId })
      .sort({ issueDate: 1 });

    if (certificates.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No certificates found. Please upload certificates to see growth analysis.'
      });
    }

    // Run ML analysis
    const analysis = mlService.analyzeGrowth(certificates);

    if (analysis.error) {
      return res.status(400).json({
        success: false,
        message: analysis.message
      });
    }

    res.status(200).json({
      success: true,
      student: {
        id: student._id,
        name: student.name,
        rollNumber: student.rollNumber,
        department: student.department
      },
      analysis
    });
  } catch (error) {
    console.error('ML Analysis error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate growth analysis'
    });
  }
};

// @desc    Get growth chart data
// @route   GET /api/ml/growth-chart
// @access  Private (Student - own, Teacher/Admin - any)
exports.getGrowthChart = async (req, res) => {
  try {
    let studentId = req.user.id;

    // Teachers and admins can view any student's chart
    if ((req.user.role === 'teacher' || req.user.role === 'admin') && req.query.studentId) {
      studentId = req.query.studentId;
    }

    const certificates = await Certificate.find({ student: studentId })
      .sort({ issueDate: 1 });

    const chartData = mlService.generateGrowthChart(certificates);

    res.status(200).json({
      success: true,
      chartData
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to generate growth chart'
    });
  }
};

// @desc    Get peer comparison
// @route   GET /api/ml/peer-comparison
// @access  Private (Student)
exports.getPeerComparison = async (req, res) => {
  try {
    const studentId = req.user.id;
    const student = await User.findById(studentId);

    if (!student) {
      return res.status(404).json({
        success: false,
        message: 'Student not found'
      });
    }

    // Get all students in same department
    const peers = await User.find({ 
      role: 'student', 
      department: student.department,
      isApproved: true,
      _id: { $ne: studentId }
    }).select('_id');

    // Get certificate counts
    const myCount = await Certificate.countDocuments({ student: studentId });
    
    const peerCounts = await Promise.all(
      peers.map(async (peer) => {
        const count = await Certificate.countDocuments({ student: peer._id });
        return count;
      })
    );

    // Calculate statistics
    const totalPeers = peerCounts.length;
    const avgCertificates = totalPeers > 0 
      ? peerCounts.reduce((sum, count) => sum + count, 0) / totalPeers 
      : 0;
    const maxCertificates = totalPeers > 0 ? Math.max(...peerCounts) : 0;
    
    // Calculate percentile
    const betterThanCount = peerCounts.filter(count => myCount > count).length;
    const percentile = totalPeers > 0 
      ? Math.round((betterThanCount / totalPeers) * 100) 
      : 0;

    res.status(200).json({
      success: true,
      comparison: {
        myCertificates: myCount,
        avgCertificates: Math.round(avgCertificates * 10) / 10,
        maxCertificates,
        percentile,
        totalPeers,
        department: student.department
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to get peer comparison'
    });
  }
};

// @desc    Get skill distribution
// @route   GET /api/ml/skill-distribution
// @access  Private (Student - own, Teacher/Admin - any)
exports.getSkillDistribution = async (req, res) => {
  try {
    let studentId = req.user.id;

    if ((req.user.role === 'teacher' || req.user.role === 'admin') && req.query.studentId) {
      studentId = req.query.studentId;
    }

    const certificates = await Certificate.find({ student: studentId });

    const distribution = {
      Programming: 0,
      Backend: 0,
      Frontend: 0,
      Database: 0,
      Cloud: 0,
      'AI/ML': 0,
      Mobile: 0,
      Other: 0
    };

    certificates.forEach(cert => {
      const category = cert.category || 'Other';
      if (distribution.hasOwnProperty(category)) {
        distribution[category]++;
      } else {
        distribution.Other++;
      }
    });

    res.status(200).json({
      success: true,
      distribution
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to get skill distribution'
    });
  }
};
