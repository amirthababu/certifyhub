import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { mlAPI } from '../services/api';
import { getErrorMessage, getScoreColor, getScoreBgColor, getPriorityColor } from '../utils/helpers';

const COLORS = ['#3b82f6','#10b981','#f59e0b','#ef4444','#8b5cf6','#ec4899','#14b8a6','#64748b'];

// Domain badge colour — cycles through a palette
const DOMAIN_COLORS = [
  'bg-blue-100 text-blue-700 border-blue-200',
  'bg-green-100 text-green-700 border-green-200',
  'bg-purple-100 text-purple-700 border-purple-200',
  'bg-yellow-100 text-yellow-700 border-yellow-200',
  'bg-pink-100 text-pink-700 border-pink-200',
  'bg-indigo-100 text-indigo-700 border-indigo-200',
  'bg-orange-100 text-orange-700 border-orange-200',
  'bg-teal-100 text-teal-700 border-teal-200',
];

const MLAnalysis = () => {
  const navigate = useNavigate();
  const [analysis, setAnalysis] = useState(null);
  const [loading,  setLoading]  = useState(true);
  const [error,    setError]    = useState('');

  useEffect(() => { fetchAnalysis(); }, []); // eslint-disable-line

  const fetchAnalysis = async () => {
    setLoading(true);
    try {
      const res = await mlAPI.getMyAnalysis();
      if (res.data.hasData) setAnalysis(res.data.analysis);
      else setError(res.data.message || 'No analysis available');
    } catch(e) { setError(getErrorMessage(e)); }
    finally    { setLoading(false); }
  };

  if (loading) return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"/>
        <p className="mt-4 text-gray-600">Analysing your learning journey...</p>
      </div>
    </div>
  );

  if (error || !analysis) return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8 text-center">
        <svg className="w-16 h-16 text-yellow-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
        </svg>
        <h2 className="text-xl font-semibold text-gray-900 mb-2">No Analysis Available</h2>
        <p className="text-gray-600 mb-6">{error || 'Upload certificates to view your growth analysis'}</p>
        <button onClick={()=>navigate('/student')} className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700">
          Go to Dashboard
        </button>
      </div>
    </div>
  );

  const categoryData = Object.entries(analysis.features.categoryCounts)
    .map(([name, value]) => ({ name, value })).filter(i => i.value > 0);

  const f = analysis.features;

  // Format monthsActive — always a whole number (round up, minimum 1)
  const monthsDisplay = Math.max(1, Math.round(f.monthsActive || 0));

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">

        {/* Header */}
        <div className="mb-8">
          <button onClick={()=>navigate('/student')} className="mb-4 flex items-center text-blue-600 hover:text-blue-800">
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
            </svg>
            Back to Dashboard
          </button>
          <h1 className="text-3xl font-bold text-gray-900">AI Growth Analysis</h1>
          <p className="text-gray-600 mt-2">Powered by Random Forest Machine Learning</p>
        </div>

        {/* Score Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Skill Level Score</h3>
            <div className="flex items-center justify-between mb-4">
              <div className={`text-5xl font-bold ${getScoreColor(analysis.skillLevelScore)}`}>{analysis.skillLevelScore}</div>
              <div className="text-right">
                <p className="text-sm text-gray-500">out of 100</p>
                <p className="text-xs text-gray-400 mt-1">Based on volume, diversity &amp; progression</p>
              </div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div className={`h-3 rounded-full ${getScoreBgColor(analysis.skillLevelScore)}`} style={{ width:`${analysis.skillLevelScore}%` }}/>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Career Readiness Score</h3>
            <div className="flex items-center justify-between mb-4">
              <div className={`text-5xl font-bold ${getScoreColor(analysis.careerReadinessScore)}`}>{analysis.careerReadinessScore}</div>
              <div className="text-right">
                <p className="text-sm text-gray-500">out of 100</p>
                <p className="text-xs text-gray-400 mt-1">Random Forest Ensemble (5 Trees)</p>
              </div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3 mb-4">
              <div className={`h-3 rounded-full ${getScoreBgColor(analysis.careerReadinessScore)}`} style={{ width:`${analysis.careerReadinessScore}%` }}/>
            </div>
            <div className="grid grid-cols-2 gap-2 text-sm">
              {[['Volume',f.totalCertificates ? analysis.careerReadinessBreakdown.volume : 0, 25],
                ['Diversity', analysis.careerReadinessBreakdown.diversity, 20],
                ['Progression', analysis.careerReadinessBreakdown.progression, 25],
                ['Consistency', analysis.careerReadinessBreakdown.consistency, 15],
                ['Specialization', analysis.careerReadinessBreakdown.specialization, 15]].map(([l, v, mx]) => (
                <div key={l} className={`flex justify-between ${l==='Specialization'?'col-span-2':''}`}>
                  <span className="text-gray-600">{l}:</span>
                  <span className="font-medium">{v}/{mx}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Career Predictions */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h3 className="text-lg font-semibold mb-4">Career Role Predictions</h3>
          <div className="space-y-3">
            {analysis.predictedRoles.map((role, i) => (
              <div key={i}>
                <div className="flex justify-between items-center mb-1">
                  <span className="font-medium">{role.role}</span>
                  <span className="text-sm text-gray-600">{role.confidence}% confidence</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-600 h-2 rounded-full" style={{ width:`${role.confidence}%` }}/>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Growth Chart */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h3 className="text-lg font-semibold mb-4">Certificate Growth Over Time</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={analysis.growthChart}>
              <CartesianGrid strokeDasharray="3 3"/>
              <XAxis dataKey="date"/>
              <YAxis/>
              <Tooltip/>
              <Legend/>
              <Line type="monotone" dataKey="count" stroke="#3b82f6" strokeWidth={2} name="Total Certificates"/>
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Category Distribution + Peer Comparison */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Skill Distribution</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={categoryData} cx="50%" cy="50%" outerRadius={100} dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                  {categoryData.map((entry, i) => <Cell key={i} fill={COLORS[i % COLORS.length]}/>)}
                </Pie>
                <Tooltip/>
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Peer Comparison</h3>
            <div className="space-y-4">
              {[
                { label:'Your Certificates', val:analysis.peerComparison.userCertificates, pct:(analysis.peerComparison.userCertificates/analysis.peerComparison.topPerformer)*100, color:'bg-blue-600' },
                { label:'Dept. Average',     val:analysis.peerComparison.departmentAverage, pct:(analysis.peerComparison.departmentAverage/analysis.peerComparison.topPerformer)*100, color:'bg-gray-500' },
                { label:'Top Performer',     val:analysis.peerComparison.topPerformer,      pct:100, color:'bg-green-600' },
              ].map(({ label, val, pct, color }) => (
                <div key={label}>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-600">{label}</span>
                    <span className="font-bold">{val}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className={`${color} h-2 rounded-full`} style={{ width:`${pct}%` }}/>
                  </div>
                </div>
              ))}
              <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-gray-700"><span className="font-semibold">Ranking:</span> {analysis.peerComparison.ranking}</p>
                <p className="text-sm text-gray-700 mt-1"><span className="font-semibold">Percentile:</span> {analysis.peerComparison.percentile}th</p>
              </div>
            </div>
          </div>
        </div>

        {/* AI Recommendations */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h3 className="text-lg font-semibold mb-1">AI-Powered Recommendations</h3>
          {f.areasOfInterest?.length > 0 && (
            <p className="text-sm text-indigo-600 mb-4 font-medium">
              🎯 Personalised based on your interests: <strong>{f.areasOfInterest.join(', ')}</strong>
            </p>
          )}
          <div className="space-y-4">
            {analysis.recommendations.map((rec, i) => (
              <div key={i} className={`border-l-4 p-4 rounded ${getPriorityColor(rec.priority)}`}>
                <div className="flex flex-wrap justify-between items-start gap-2 mb-2">
                  <h4 className="font-semibold text-lg">{rec.skill}</h4>
                  <div className="flex gap-2 flex-wrap">
                    {rec.type === 'interest_gap'     && <span className="px-3 py-1 rounded-full text-xs font-bold bg-red-100 text-red-700 border border-red-300">🔥 Interest Gap</span>}
                    {rec.type === 'interest_advance' && <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-100 text-indigo-700 border border-indigo-300">⭐ Your Interest</span>}
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getPriorityColor(rec.priority)}`}>{rec.priority} Priority</span>
                  </div>
                </div>
                <p className="text-gray-700 mb-3">{rec.reason}</p>
                <div className="flex items-center text-sm text-gray-600 mb-2">
                  <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                  </svg>
                  Estimated Time: {rec.estimatedTime}
                </div>
                <div className="mt-2">
                  <p className="text-sm font-medium text-gray-700 mb-1">Suggested Courses:</p>
                  <div className="flex flex-wrap gap-2">
                    {rec.suggestions.map((s, j) => <span key={j} className="px-2 py-1 bg-white rounded text-xs border">{s}</span>)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ── Learning Analytics ────────────────────────────────────────────── */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-lg font-semibold mb-4">Learning Analytics</h3>

          {/* Stats grid — 3 items (Certs/Month removed) */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">

            {/* Total Certificates */}
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-3xl font-bold text-blue-600">{f.totalCertificates}</p>
              <p className="text-sm text-gray-600 mt-1 font-medium">Total Certificates</p>
            </div>

            {/* Unique Categories — domain count from titles */}
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-3xl font-bold text-green-600">{f.uniqueCategories}</p>
              <p className="text-sm text-gray-600 mt-1 font-medium">Unique Tech Domains</p>
              <p className="text-xs text-gray-400 mt-0.5">Extracted from certificate titles</p>
            </div>

            {/* Months Active — total learning duration */}
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-3xl font-bold text-orange-600">{monthsDisplay}</p>
              <p className="text-sm text-gray-600 mt-1 font-medium">Months Active</p>
              <p className="text-xs text-gray-400 mt-0.5">Total learning duration (courses + internships + events)</p>
            </div>
          </div>

          {/* Domain badges — shows each unique domain detected */}
          {f.uniqueDomainList && f.uniqueDomainList.length > 0 && (
            <div className="mb-6">
              <p className="text-sm font-semibold text-gray-700 mb-2 flex items-center gap-1">
                <svg className="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
                Tech Domains Identified ({f.uniqueDomainList.length})
              </p>
              <div className="flex flex-wrap gap-2">
                {f.uniqueDomainList.map((domain, i) => (
                  <span key={domain}
                    className={`px-3 py-1 rounded-full text-xs font-semibold border ${DOMAIN_COLORS[i % DOMAIN_COLORS.length]}`}>
                    {domain}
                  </span>
                ))}
              </div>
              <p className="text-xs text-gray-400 mt-2">
                These domains were automatically extracted from your certificate titles.
              </p>
            </div>
          )}

          {/* Top Keywords */}
          {f.topKeywords?.length > 0 && (
            <div>
              <p className="text-sm font-medium text-gray-700 mb-2">Top Keywords from your certificates:</p>
              <div className="flex flex-wrap gap-2">
                {f.topKeywords.map((kw, i) => (
                  <span key={i} className="px-2 py-1 bg-blue-50 text-blue-700 rounded text-xs font-medium border border-blue-200">{kw}</span>
                ))}
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};

export default MLAnalysis;
