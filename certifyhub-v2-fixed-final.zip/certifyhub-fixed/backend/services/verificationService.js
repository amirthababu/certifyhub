/**
 * verificationService.js  — v3
 *
 * REAL automatic verification pipeline:
 *  1. Extract text from PDF or image (Tesseract with preprocessing)
 *  2. Scan QR code from image at multiple scales (jimp + jsQR)
 *  3. If QR URL found → HTTP GET to the issuer page → verified if reachable (2xx/3xx)
 *  4. If no QR → parse cert ID from OCR text → build issuer verify URL → HTTP GET
 *  5. Mark as VERIFIED if issuer page is reachable
 *
 * All OCR packages are lazy-loaded (server starts even without npm install).
 */

const axios = require('axios');
const fs    = require('fs');
const path  = require('path');

/* ── Issuer verification URL builders ── */
const ISSUER_VERIFY_URLS = {
  Coursera:  id => `https://www.coursera.org/verify/${id}`,
  Udemy:     id => `https://www.udemy.com/certificate/${id}/`,
  LinkedIn:  id => `https://www.linkedin.com/learning/certificates/${id}`,
  Google:    id => `https://skillshop.credential.net/verify/${id}`,
  Microsoft: id => `https://learn.microsoft.com/api/credentials/share/${id}`,
  AWS:       id => `https://aws.amazon.com/verification/${id}`,
};

/* ── Certificate ID regex per issuer ── */
const CERT_ID_PATTERNS = {
  Coursera:  /\b([A-Z0-9]{8,20})\b/,
  Udemy:     /UC-([A-Za-z0-9\-]{20,42})/,
  LinkedIn:  /\b([A-Za-z0-9]{28,52})\b/,
  Google:    /\b([A-Za-z0-9\-]{14,42})\b/,
  Microsoft: /\b([A-Za-z0-9\-]{36})\b/,
  AWS:       /\b([A-Z0-9]{12,22})\b/,
};

/* ════════════════════════════════════════════════
   TEXT EXTRACTION
   ════════════════════════════════════════════════ */
async function extractTextFromPDF(filePath) {
  try {
    const pdfParse = require('pdf-parse');
    const data     = await pdfParse(fs.readFileSync(filePath));
    return data.text || '';
  } catch(e) { console.warn('[OCR] pdf-parse:', e.message); return ''; }
}

/**
 * Extract text from an image with Tesseract.
 * We try two passes: original + greyscale-enhanced (via Jimp).
 * Whichever gives more text wins.
 */
async function extractTextFromImage(filePath) {
  const Tesseract = (() => { try { return require('tesseract.js'); } catch { return null; } })();
  if (!Tesseract) { console.warn('[OCR] tesseract.js not installed'); return ''; }

  const opts = { logger: () => {} };
  let bestText = '';

  // Pass 1 — raw file
  try {
    const { data: { text } } = await Tesseract.recognize(filePath, 'eng', opts);
    if ((text||'').length > bestText.length) bestText = text;
  } catch(e) { console.warn('[OCR] Tesseract pass 1:', e.message); }

  // Pass 2 — greyscale + contrast via Jimp then OCR
  try {
    const Jimp       = require('jimp');
    const tmpPath    = filePath + '_ocr_tmp.png';
    const img        = await Jimp.read(filePath);
    img.greyscale().contrast(0.3).normalize().write(tmpPath);
    const { data: { text } } = await Tesseract.recognize(tmpPath, 'eng', opts);
    if ((text||'').length > bestText.length) bestText = text;
    if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);
  } catch(e) { console.warn('[OCR] Tesseract pass 2:', e.message); }

  return bestText;
}

/* ════════════════════════════════════════════════
   QR CODE SCANNING  — multi-scale, multi-strategy
   ════════════════════════════════════════════════ */
async function extractQRFromImage(filePath) {
  const Jimp = (() => { try { return require('jimp'); }  catch { return null; } })();
  const jsQR = (() => { try { return require('jsqr');  } catch { return null; } })();
  if (!Jimp || !jsQR) { console.warn('[QR] jimp or jsqr not installed'); return null; }

  try {
    const original = await Jimp.read(filePath);
    // Extended scale list — small and large QR codes both covered
    const scales = [1, 2, 1.5, 3, 0.75, 0.5, 4];
    const inversions = ['dontInvert', 'attemptBoth'];

    for (const scale of scales) {
      for (const grey of [false, true]) {
        for (const inv of inversions) {
          try {
            const proc = original.clone();
            if (scale !== 1) proc.scale(scale);
            if (grey) proc.greyscale().contrast(0.3).normalize();
            const { data, width, height } = proc.bitmap;
            const code = jsQR(new Uint8ClampedArray(data), width, height, { inversionAttempts: inv });
            if (code && code.data) {
              console.log(`[QR] Found scale=${scale} grey=${grey} inv=${inv}: ${code.data.slice(0,60)}`);
              return code.data;
            }
          } catch(_) { /* try next */ }
        }
      }
    }
    // Final attempt: full binarise + invert
    try {
      const sharp = original.clone().greyscale().contrast(1).normalize();
      const { data, width, height } = sharp.bitmap;
      const code = jsQR(new Uint8ClampedArray(data), width, height, { inversionAttempts: 'attemptBoth' });
      if (code && code.data) { console.log('[QR] Found via binarise'); return code.data; }
    } catch(_) {}

    return null;
  } catch(e) { console.warn('[QR] scan error:', e.message); return null; }
}

/* ════════════════════════════════════════════════
   REAL HTTP VERIFICATION
   Opens the verification URL — marks verified if page is reachable (2xx/3xx).
   Uses GET (not HEAD) so redirects are followed and real content is checked.
   ════════════════════════════════════════════════ */
async function reachVerificationURL(url) {
  try {
    // Follow redirects, accept any status < 500 as "page exists"
    const r = await axios.get(url, {
      timeout:        10000,
      maxRedirects:   10,
      validateStatus: s => s < 500,
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; CertifyHub-Verifier/1.0)',
        'Accept':     'text/html,application/xhtml+xml,*/*',
      }
    });
    const ok = r.status >= 200 && r.status < 400;
    // Extra check: if the page body contains "not found" / "invalid" text → unverified
    const body = (typeof r.data === 'string') ? r.data.toLowerCase() : '';
    const pageInvalid = body.length > 50 && (
      body.includes('certificate not found') ||
      body.includes('invalid certificate') ||
      body.includes('page not found') ||
      body.includes('404')
    );
    return {
      reached:    ok && !pageInvalid,
      statusCode: r.status,
      url,
      reason: (ok && !pageInvalid)
        ? `Verification page reached successfully (HTTP ${r.status})`
        : `Certificate page not found at issuer (HTTP ${r.status})`
    };
  } catch(e) {
    return { reached: false, statusCode: 0, url, reason: `Could not reach ${url}: ${e.message}` };
  }
}

/* ════════════════════════════════════════════════
   CERT ID PARSER  — smarter context-aware version
   ════════════════════════════════════════════════ */
function parseCertificateId(ocrText, issuer) {
  if (!ocrText) return null;

  // 1. Try explicit label patterns first (most reliable)
  const labelPatterns = [
    /(?:certificate\s*(?:id|no|number|code)[:\s#]+)([A-Za-z0-9\-_]{6,50})/i,
    /(?:credential\s*(?:id|no|number)[:\s#]+)([A-Za-z0-9\-_]{6,50})/i,
    /(?:verification\s*(?:id|code)[:\s#]+)([A-Za-z0-9\-_]{6,50})/i,
    /(?:cert(?:ification)?\s*(?:id|code)[:\s#]+)([A-Za-z0-9\-_]{6,50})/i,
  ];
  for (const pat of labelPatterns) {
    const m = ocrText.match(pat);
    if (m && m[1]) return m[1].trim();
  }

  // 2. Udemy UC- prefix — very reliable
  const udemyM = ocrText.match(/UC-([A-Za-z0-9\-]{20,42})/);
  if (udemyM) return `UC-${udemyM[1]}`;

  // 3. Issuer-specific pattern
  if (issuer && CERT_ID_PATTERNS[issuer]) {
    const m = ocrText.match(CERT_ID_PATTERNS[issuer]);
    if (m) return (m[1] || m[0]).trim();
  }

  // 4. Generic: long alphanumeric sequence that looks like a cert ID
  const generic = ocrText.match(/\b([A-Z0-9][A-Z0-9\-]{10,38}[A-Z0-9])\b/);
  if (generic) return generic[1];

  return null;
}

/* ════════════════════════════════════════════════
   MAIN AUTO-VERIFY PIPELINE — v4
   ════════════════════════════════════════════════ */
async function autoVerifyCertificate({ filePath, fileType, issuer, certificateId: manualId, qrCodeData: manualQR }) {
  const result = {
    status:          'unverified',
    method:          'none',
    extractedId:     null,
    extractedQR:     null,
    verificationUrl: null,
    message:         'No verification data found',
    verifiedAt:      undefined,
  };

  const mime    = (fileType || '').toLowerCase();
  const ext     = mime.includes('/') ? mime.split('/')[1] : path.extname(filePath).replace('.','').toLowerCase();
  const isImage = ['jpg','jpeg','png','gif','webp'].includes(ext);
  const isPDF   = ext === 'pdf' || mime.includes('pdf');

  /* ── Step 1: extract text from file ── */
  let ocrText = '';
  if (isPDF)        ocrText = await extractTextFromPDF(filePath);
  else if (isImage) ocrText = await extractTextFromImage(filePath);
  console.log(`[Verify] OCR extracted ${ocrText.length} chars`);

  /* ── Step 2: QR code — use manual value OR rescan the file ──
     Important: always try to rescan the actual uploaded file even if manualQR was passed,
     because the OCR-extract endpoint may have missed the QR (different file copy). */
  let qrData = null;

  // Priority 1: valid URL passed from form (extracted by OCR-extract endpoint)
  if (manualQR && (manualQR.startsWith('http://') || manualQR.startsWith('https://'))) {
    qrData = manualQR;
    result.extractedQR = qrData;
    result.method = 'qr_code';  // was 'qr_manual' — not a valid enum value
    console.log('[Verify] Using manual QR URL:', qrData.slice(0, 80));
  }

  // Priority 2: rescan the uploaded file for QR (works for images)
  if (!qrData && isImage) {
    const scanned = await extractQRFromImage(filePath);
    if (scanned) {
      qrData = scanned;
      result.extractedQR = scanned;
      result.method = 'qr_scan';
      console.log('[Verify] QR found by scan:', qrData.slice(0, 80));
    }
  }

  // Priority 3: find any verification URL in OCR text (covers PDFs with embedded links)
  if (!qrData && ocrText) {
    const urlMatches = ocrText.match(/https?:\/\/[^\s"'<>\n]{10,300}/g) || [];
    for (const raw of urlMatches) {
      const candidate = raw.replace(/[.,;:)\]]+$/, '');
      if (/verif|certif|credential|learn|skill|badge/i.test(candidate)) {
        qrData = candidate;
        result.extractedQR = candidate;
        result.method = 'url_from_text';
        console.log('[Verify] URL found in OCR text:', candidate.slice(0, 80));
        break;
      }
    }
  }

  /* ── Step 3: Certificate ID ──
     Use manual value if provided; otherwise extract from OCR text. */
  let certId = null;

  // Priority 1: valid cert ID passed from form
  if (manualId && manualId.trim().length >= 5) {
    certId = manualId.trim();
    result.extractedId = certId;
    result.method = result.method || 'id_manual';
    console.log('[Verify] Using manual cert ID:', certId);
  }

  // Priority 2: extract from OCR text
  if (!certId && ocrText) {
    certId = parseCertificateId(ocrText, issuer);
    if (certId) {
      result.extractedId = certId;
      result.method = result.method || 'ocr_id';
      console.log('[Verify] Cert ID extracted from OCR:', certId);
    }
  }

  /* ── Step 4: build verification URL and check it ── */
  let verifyURL = null;

  if (qrData && /^https?:\/\//.test(qrData)) {
    verifyURL = qrData;                                    // QR / URL-in-text takes priority
  } else if (certId && issuer && ISSUER_VERIFY_URLS[issuer]) {
    verifyURL = ISSUER_VERIFY_URLS[issuer](certId);        // known issuer + ID
  } else if (certId) {
    const detected = detectIssuerFromText(ocrText || '', certId);
    if (detected && ISSUER_VERIFY_URLS[detected]) {
      verifyURL = ISSUER_VERIFY_URLS[detected](certId);
      result.method = result.method || 'auto_detect';
    }
  }

  if (verifyURL) {
    result.verificationUrl = verifyURL;
    console.log('[Verify] Checking URL:', verifyURL);
    const check = await reachVerificationURL(verifyURL);
    result.status  = check.reached ? 'verified' : 'unverified';
    result.message = check.reason;
    if (check.reached) {
      result.verifiedAt = new Date();
      console.log('[Verify] ✅ VERIFIED via', verifyURL);
    } else {
      console.log('[Verify] ❌ NOT verified:', check.reason);
    }
  } else {
    result.message = (result.extractedId || result.extractedQR)
      ? `Found ${result.extractedQR ? 'QR data' : 'Certificate ID'} but could not build a verification URL`
      : ocrText.length > 20
        ? 'Text extracted but no Certificate ID, QR code, or verification URL found'
        : 'Could not extract any data from the certificate file';
  }

  return result;
}

/* ────────────────────────────────────────────────
   Auto-detect issuer from OCR text + cert ID shape
   ──────────────────────────────────────────────── */
function detectIssuerFromText(text, certId) {
  const lo = text.toLowerCase();
  if (lo.includes('coursera'))  return 'Coursera';
  if (lo.includes('udemy') || (certId||'').startsWith('UC-')) return 'Udemy';
  if (lo.includes('linkedin'))  return 'LinkedIn';
  if (lo.includes('google'))    return 'Google';
  if (lo.includes('microsoft')) return 'Microsoft';
  if (lo.includes('amazon') || lo.includes('aws')) return 'AWS';
  return null;
}

/* ── Manual verification by teacher/admin ── */
function manualVerification(verifiedBy) {
  return {
    status: 'verified', method: 'manual',
    message: 'Manually verified by teacher or admin',
    verifiedAt: new Date(), verifiedBy,
  };
}

function getSupportedIssuers() {
  return ['Coursera','Udemy','LinkedIn','Google','Microsoft','AWS','Other']
    .map(n => ({ name: n, code: n.toLowerCase() }));
}

module.exports = {
  autoVerifyCertificate, manualVerification, getSupportedIssuers,
  extractTextFromImage, extractTextFromPDF, extractQRFromImage,
  parseCertificateId, reachVerificationURL,
};
