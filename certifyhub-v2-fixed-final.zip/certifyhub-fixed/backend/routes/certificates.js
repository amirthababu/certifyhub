/**
 * certificates.js  — v3
 * Includes:
 *   POST /ocr-extract  — smart OCR scan + QR decode, returns structured fields
 *   POST /upload       — save cert + real auto-verification
 *   All other CRUD routes
 */
const express     = require('express');
const router      = express.Router();
const path        = require('path');
const fs          = require('fs');
const Certificate = require('../models/Certificate');
const User        = require('../models/User');
const { auth, studentOnly, teacherOrAdmin, adminOnly } = require('../middleware/auth');
const upload      = require('../middleware/upload');
const { extractKeywords, categorizeCertificate, determineSkillLevel, searchCertificates } = require('../services/nlpService');
const { autoVerifyCertificate, manualVerification } = require('../services/verificationService');

/* ══════════════════════════════════════════════════════════
   OCR EXTRACT   POST /api/certificates/ocr-extract
   Scans uploaded file → returns extracted fields WITHOUT saving a cert.
   ══════════════════════════════════════════════════════════ */
router.post('/ocr-extract', auth, studentOnly, upload.single('certificate'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  const filePath = req.file.path;
  const mime     = req.file.mimetype || '';
  const ext      = path.extname(req.file.filename).substring(1).toLowerCase();
  const isImage  = ['jpg','jpeg','png'].includes(ext);
  const isPDF    = ext === 'pdf';

  try {
    let ocrText    = '';
    let qrCodeData = '';

    /* ── PDF text extraction ── */
    if (isPDF) {
      try {
        const pdfParse = require('pdf-parse');
        ocrText = (await pdfParse(fs.readFileSync(filePath))).text || '';
      } catch(e) { console.warn('[OCR] pdf-parse:', e.message); }
    }

    /* ── Image: enhanced OCR + QR scan ── */
    if (isImage) {
      const Tesseract = (() => { try { return require('tesseract.js'); } catch { return null; } })();
      const Jimp      = (() => { try { return require('jimp');         } catch { return null; } })();
      const jsQR      = (() => { try { return require('jsqr');         } catch { return null; } })();

      /* OCR pass 1 – raw image */
      if (Tesseract) {
        try {
          const { data: { text } } = await Tesseract.recognize(filePath, 'eng', { logger: () => {} });
          ocrText = text || '';
        } catch(e) { console.warn('[OCR] Tesseract pass1:', e.message); }

        /* OCR pass 2 – greyscale + contrast enhanced */
        if (Jimp) {
          try {
            const tmpPath = filePath + '_grey.png';
            const img     = await Jimp.read(filePath);
            img.greyscale().contrast(0.35).normalize().write(tmpPath);
            const { data: { text } } = await Tesseract.recognize(tmpPath, 'eng', { logger: () => {} });
            if ((text||'').length > ocrText.length) ocrText = text;
            if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);
          } catch(e) { console.warn('[OCR] Tesseract pass2:', e.message); }
        }
      }

      /* QR scan – extended multi-scale + inversion strategies */
      if (Jimp && jsQR) {
        try {
          const original = await Jimp.read(filePath);
          const scales = [1, 2, 1.5, 3, 0.75, 0.5, 4];
          const inversions = ['dontInvert', 'attemptBoth'];
          outer: for (const scale of scales) {
            for (const grey of [false, true]) {
              for (const inv of inversions) {
                try {
                  const proc = original.clone();
                  if (scale !== 1) proc.scale(scale);
                  if (grey) proc.greyscale().contrast(0.3).normalize();
                  const { data, width, height } = proc.bitmap;
                  const code = jsQR(new Uint8ClampedArray(data), width, height, { inversionAttempts: inv });
                  if (code && code.data) { qrCodeData = code.data; break outer; }
                } catch(_) { /* try next */ }
              }
            }
          }
          // Final: full binarise attempt
          if (!qrCodeData) {
            const sharp = original.clone().greyscale().contrast(1).normalize();
            const { data, width, height } = sharp.bitmap;
            const code = jsQR(new Uint8ClampedArray(data), width, height, { inversionAttempts: 'attemptBoth' });
            if (code && code.data) qrCodeData = code.data;
          }
        } catch(e) { console.warn('[OCR] QR scan:', e.message); }
      }
    }

    /* For PDFs — also look for verification URLs in the extracted text */
    if (isPDF && !qrCodeData && ocrText) {
      const urlMatches = ocrText.match(/https?:\/\/[^\s"'<>\n]{10,300}/g) || [];
      for (const raw of urlMatches) {
        const candidate = raw.replace(/[.,;:)\]]+$/, '');
        if (/verif|certif|credential|learn|skill|badge/i.test(candidate)) {
          qrCodeData = candidate;
          console.log('[OCR] Verification URL found in PDF text:', candidate.slice(0, 80));
          break;
        }
      }
    }

    /* Cleanup */
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

    const extracted = parseOCRFields(ocrText, qrCodeData);
    return res.json({ ...extracted, ocrTextLength: ocrText.length });

  } catch(err) {
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    console.error('[OCR] extract error:', err);
    return res.status(500).json({ error: 'OCR processing failed' });
  }
});

/* ─── Smart OCR field parser — v4 (fixed title, description, certId, qrCodeData) ─── */
function parseOCRFields(rawText, qrCodeData) {
  const result = {
    title: '', description: '', issueDate: '',
    certificateId: '', issuer: '', qrCodeData: qrCodeData || ''
  };

  if (!rawText || rawText.trim().length < 5) return result;

  /* Normalise whitespace but preserve line structure */
  const text  = rawText.replace(/\r\n/g, '\n').replace(/[ \t]{2,}/g, ' ');
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);

  /* ── 1. Issuer detection ── */
  const ISSUER_MAP = {
    Coursera:    ['coursera'],
    Udemy:       ['udemy'],
    LinkedIn:    ['linkedin', 'linked in'],
    Google:      ['google'],
    Microsoft:   ['microsoft', 'microsoft learn'],
    AWS:         ['amazon web services', 'aws certified', 'aws'],
    NPTEL:       ['nptel', 'national programme on technology'],
    Swayam:      ['swayam'],
    IIT:         ['indian institute of technology', 'iit '],
    NASSCOM:     ['nasscom'],
    Simplilearn: ['simplilearn'],
    edX:         ['edx', 'ed-x'],
    Infosys:     ['infosys springboard', 'infosys'],
    TCS:         ['tcs ion', 'tata consultancy'],
    Oracle:      ['oracle'],
    Cisco:       ['cisco'],
  };
  const lo = text.toLowerCase();
  for (const [name, kws] of Object.entries(ISSUER_MAP)) {
    if (kws.some(k => lo.includes(k))) { result.issuer = name; break; }
  }

  /* ── 2. Certificate ID extraction — do BEFORE title so we can exclude ID-only lines ──
     Priority: explicit label > Udemy UC- > issuer pattern > generic long alphanum */
  const ID_LABEL = text.match(
    /(?:certificate\s*(?:id|no|number|code)|credential\s*(?:id|no|number)|cert(?:ification)?\s*(?:id|code)|verification\s*(?:id|code))[:\s#]+([A-Za-z0-9\-_\/]{5,60})/i
  );
  if (ID_LABEL && ID_LABEL[1]) {
    result.certificateId = ID_LABEL[1].trim();
  } else {
    const udemyM = text.match(/\b(UC-[A-Za-z0-9\-]{20,42})\b/);
    if (udemyM) {
      result.certificateId = udemyM[1];
    } else if (result.issuer && CERT_ID_PATTERNS_LOCAL[result.issuer]) {
      const m = text.match(CERT_ID_PATTERNS_LOCAL[result.issuer]);
      if (m) result.certificateId = (m[1] || m[0]).trim();
    }
    // Generic: long uppercase alphanum sequence that looks like cert ID
    if (!result.certificateId) {
      const gen = text.match(/\b([A-Z0-9][A-Z0-9\-_]{8,40}[A-Z0-9])\b/);
      if (gen && gen[1] && !/^\d+$/.test(gen[1])) result.certificateId = gen[1];
    }
  }

  /* ── 3. QR code URL — extract from OCR text if jsQR didn't find an image QR ── */
  if (!result.qrCodeData) {
    // Look for any URL that looks like a verification link in the OCR text
    const urlMatches = text.match(/https?:\/\/[^\s"'<>\n]{10,300}/g) || [];
    for (const url of urlMatches) {
      const clean = url.replace(/[.,;:)\]]+$/, '');
      if (/verif|certif|credential|learn|skill|badge/i.test(clean)) {
        result.qrCodeData = clean;
        break;
      }
    }
  }

  /* ── 4. Title extraction ──
     Strategy: skip pure boilerplate lines, then pick the LONGEST meaningful line
     in the first 15 lines that looks like a course/certification name.
     This is more robust than picking the first non-boilerplate line. */
  const PURE_BOILERPLATE = new Set([
    'certificate of completion','certificate of achievement','certificate',
    'this is to certify','this certifies that','congratulations',
    'awarded to','presented to','has successfully completed',
    'has successfully','verify at','in recognition of',
    'with distinction','upon completion','issued on','issue date',
    'valid through','credential id','certificate id','this course',
    result.issuer.toLowerCase(),
  ].filter(Boolean));

  const isBoilerplateLine = (line) => {
    const ll = line.toLowerCase().trim();
    // Exact match with a boilerplate phrase
    if (PURE_BOILERPLATE.has(ll)) return true;
    // Starts with a boilerplate phrase (multi-word match)
    for (const bp of PURE_BOILERPLATE) {
      if (bp.length > 4 && ll.startsWith(bp)) return true;
    }
    // Pure numbers / dates
    if (/^\d[\d\s\-\/,.]+$/.test(line)) return true;
    // Looks like a bare cert ID (all uppercase letters+digits, no spaces, 6+ chars)
    if (/^[A-Z0-9\-_]{6,}$/.test(line)) return true;
    // URL lines
    if (/^https?:\/\//i.test(line)) return true;
    // Very short
    if (line.length < 5) return true;
    return false;
  };

  // Candidate lines: first 20 lines, not boilerplate, has real words
  const candidates = lines.slice(0, 20).filter(l =>
    !isBoilerplateLine(l) &&
    l.length >= 6 &&
    l.length <= 200 &&
    /[a-zA-Z]{3,}/.test(l) &&
    l !== result.certificateId   // not the cert ID we just extracted
  );

  if (candidates.length > 0) {
    // Prefer longer lines (more descriptive titles), but cap at 120 chars
    const scored = candidates.map(l => ({
      line: l,
      // Score: reward length up to 80 chars, penalise very long lines
      score: Math.min(l.length, 80) - Math.max(0, l.length - 80) * 2
    }));
    scored.sort((a, b) => b.score - a.score);
    result.title = scored[0].line.slice(0, 150);
  } else if (lines.length > 0) {
    // Last resort: take the first line that has letters
    result.title = (lines.find(l => /[a-zA-Z]{3,}/.test(l)) || lines[0]).slice(0, 150);
  }

  /* ── 5. Date extraction — many formats ── */
  const MO = { jan:1,feb:2,mar:3,apr:4,may:5,jun:6,jul:7,aug:8,sep:9,oct:10,nov:11,dec:12 };
  const DATE_PATS = [
    { re: /(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})/,
      fn: m => `${m[1]}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}` },
    { re: /(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})/,
      fn: m => `${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}` },
    { re: /(\d{1,2})\s+(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)[,.\s]+(\d{4})/i,
      fn: m => `${m[3]}-${String(MO[m[2].slice(0,3).toLowerCase()]).padStart(2,'0')}-${m[1].padStart(2,'0')}` },
    { re: /(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+(\d{1,2})[,.\s]+(\d{4})/i,
      fn: m => `${m[3]}-${String(MO[m[1].slice(0,3).toLowerCase()]).padStart(2,'0')}-${m[2].padStart(2,'0')}` },
    { re: /(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)[,.\s]+(\d{4})/i,
      fn: m => `${m[2]}-${String(MO[m[1].slice(0,3).toLowerCase()]).padStart(2,'0')}-01` },
  ];
  for (const { re, fn } of DATE_PATS) {
    const m = text.match(re);
    if (m) {
      try {
        const iso = fn(m);
        const d   = new Date(iso);
        if (!isNaN(d) && d.getFullYear() >= 2010 && d <= new Date()) {
          result.issueDate = iso;
          break;
        }
      } catch(_) { /* skip */ }
    }
  }

  /* ── 6. Description — meaningful content lines, NOT the title, NOT cert IDs, NOT QR URLs ── */
  const descLines = lines.filter(l => {
    if (l === result.title) return false;
    if (l === result.certificateId) return false;
    if (result.qrCodeData && l.includes(result.qrCodeData.slice(0, 20))) return false;
    if (/^https?:\/\//i.test(l)) return false;       // no raw URLs
    if (/^[A-Z0-9\-_]{6,}$/.test(l)) return false;   // no bare IDs
    if (isBoilerplateLine(l)) return false;
    if (l.length < 20) return false;
    if (!/[a-zA-Z]{4,}/.test(l)) return false;
    return true;
  }).slice(0, 3);

  result.description = descLines.join(' ').slice(0, 350);

  // If description is empty, build a sensible fallback from title + issuer
  if (!result.description && result.title) {
    const issuerPart = result.issuer ? ` by ${result.issuer}` : '';
    result.description = `Certificate for "${result.title}"${issuerPart}.`;
  }

  return result;
}

/* Local copy used only inside parseOCRFields */
const CERT_ID_PATTERNS_LOCAL = {
  Coursera:  /\b([A-Z0-9]{8,22})\b/,
  LinkedIn:  /\b([A-Za-z0-9]{28,52})\b/,
  Google:    /\b([A-Za-z0-9\-]{14,42})\b/,
  Microsoft: /\b([A-Za-z0-9\-]{36})\b/,
  AWS:       /\b([A-Z0-9]{12,22})\b/,
};

/* ══════════════════════════════════════════════════════════
   UPLOAD   POST /api/certificates/upload
   ══════════════════════════════════════════════════════════ */
router.post('/upload', auth, studentOnly, upload.single('certificate'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'Please upload a certificate file' });

    const {
      title, description, issueDate,
      certificateId, issuer, qrCodeData,
      certificateType,
      courseStartDate, courseEndDate,
      internshipStartDate, internshipEndDate
    } = req.body;

    if (!title || !description || !issueDate) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ error: 'Please provide title, description, and issue date' });
    }

    const keywords   = extractKeywords(`${title} ${description}`);
    const category   = categorizeCertificate(title, description);
    const skillLevel = determineSkillLevel(title, description);

    /* Real auto-verification */
    let autoV = { status: 'unverified', method: 'none', message: 'No verification attempted' };
    try {
      autoV = await autoVerifyCertificate({
        filePath:      req.file.path,
        fileType:      req.file.mimetype,
        issuer:        issuer      || '',
        certificateId: certificateId || '',
        qrCodeData:    qrCodeData  || '',
      });
    } catch(e) { console.error('[Verify] Non-fatal error:', e.message); }

    const certificate = new Certificate({
      student:      req.userId,
      title, description,
      issueDate:    new Date(issueDate),
      certificateType: certificateType || 'course',
      courseStartDate:      courseStartDate      ? new Date(courseStartDate)      : undefined,
      courseEndDate:        courseEndDate        ? new Date(courseEndDate)        : undefined,
      internshipStartDate:  internshipStartDate  ? new Date(internshipStartDate)  : undefined,
      internshipEndDate:    internshipEndDate    ? new Date(internshipEndDate)    : undefined,
      fileName:  req.file.filename,
      filePath:  req.file.path,
      fileType:  req.file.mimetype,
      certificateId: autoV.extractedId  || certificateId  || '',
      issuer:        issuer || '',
      qrCodeData:    autoV.extractedQR  || qrCodeData     || '',
      verificationStatus: autoV.status,
      verificationMethod: autoV.method,
      verifiedAt:    autoV.verifiedAt   || undefined,
      ocrExtracted:  !!(autoV.extractedId || autoV.extractedQR),
      category, keywords, skillLevel,
    });

    await certificate.save();
    await certificate.populate('student', 'name rollNumber department');

    /* Dept-filtered teacher notifications */
    const notify = req.app.get('sendNotificationToTeachers');
    if (notify) notify(certificate).catch(e => console.error('[Notify]', e.message));

    return res.status(201).json({
      message: 'Certificate uploaded successfully',
      certificate,
      autoVerification: {
        status:          autoV.status,
        method:          autoV.method,
        message:         autoV.message,
        extractedId:     autoV.extractedId     || null,
        extractedQR:     autoV.extractedQR     || null,
        verificationUrl: autoV.verificationUrl || null,
      }
    });
  } catch(error) {
    console.error('[Upload] error:', error);
    if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
    return res.status(500).json({ error: error.message || 'Server error during upload' });
  }
});

/* ══════ GET my-certificates ══════ */
router.get('/my-certificates', auth, studentOnly, async (req, res) => {
  try {
    const certs = await Certificate.find({ student: req.userId }).sort({ issueDate: -1 }).select('-filePath');
    res.json({ certificates: certs, count: certs.length });
  } catch { res.status(500).json({ error: 'Server error' }); }
});

/* ══════ GET all (teacher/admin) ══════ */
router.get('/all', auth, teacherOrAdmin, async (req, res) => {
  try {
    const { year, month, verificationStatus, studentId } = req.query;
    let query = {};

    if (studentId) {
      query.student = studentId;
    } else if (req.userRole === 'teacher') {
      const dept = req.user.department || req.user.subject;
      if (dept) {
        const ds = await User.find({ role:'student', isApproved:true, department:{ $regex:new RegExp(`^${dept.trim()}$`,'i') } }).select('_id');
        query.student = { $in: ds.map(d => d._id) };
      }
    }

    if (year && year !== 'all') {
      const mn = (month && month !== 'all') ? parseInt(month) : null;
      query.issueDate = mn
        ? { $gte: new Date(parseInt(year), mn-1, 1), $lte: new Date(parseInt(year), mn, 0, 23, 59, 59) }
        : { $gte: new Date(`${year}-01-01`), $lte: new Date(`${year}-12-31`) };
    } else if (month && month !== 'all') {
      query.$expr = { $eq: [{ $month: '$issueDate' }, parseInt(month)] };
    }
    if (verificationStatus && verificationStatus !== 'all') query.verificationStatus = verificationStatus;

    const certs = await Certificate.find(query).populate('student','name rollNumber department').sort({ issueDate:-1 }).select('-filePath');
    res.json({ certificates: certs, count: certs.length });
  } catch(e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

/* ══════ GET search ══════ */
router.get('/search', auth, teacherOrAdmin, async (req, res) => {
  try {
    const { query, year, verificationStatus } = req.query;
    let dbQ = {};
    if (req.userRole === 'teacher') {
      const dept = req.user.department || req.user.subject;
      if (dept) {
        const ds = await User.find({ role:'student', isApproved:true, department:{ $regex:new RegExp(`^${dept.trim()}$`,'i') } }).select('_id');
        dbQ.student = { $in: ds.map(d => d._id) };
      }
    }
    if (year && year !== 'all') dbQ.issueDate = { $gte:new Date(`${year}-01-01`), $lte:new Date(`${year}-12-31`) };
    if (verificationStatus && verificationStatus !== 'all') dbQ.verificationStatus = verificationStatus;

    let results = await Certificate.find(dbQ).populate('student','name rollNumber department').sort({ issueDate:-1 });
    if (query && query.trim()) results = searchCertificates(results, query);
    res.json({ certificates: results.map(c => { const { filePath, ...r } = c._doc||c; return r; }), count: results.length });
  } catch { res.status(500).json({ error: 'Server error' }); }
});

/* ══════ GET download/:id ══════ */
router.get('/download/:id', auth, async (req, res) => {
  try {
    const c = await Certificate.findById(req.params.id);
    if (!c) return res.status(404).json({ error: 'Not found' });
    if (req.userRole === 'student' && c.student.toString() !== req.userId.toString())
      return res.status(403).json({ error: 'Access denied' });
    if (!fs.existsSync(c.filePath)) return res.status(404).json({ error: 'File not found on server' });

    // Determine safe filename with correct extension
    const ext          = path.extname(c.fileName || '') || path.extname(c.filePath) || '.pdf';
    const safeTitle    = (c.title || 'certificate').replace(/[^a-zA-Z0-9_\-\s]/g, '').trim().replace(/\s+/g, '_').slice(0, 60);
    const downloadName = `${safeTitle}${ext}`;

    // Set Content-Disposition so browser knows the real filename
    res.setHeader('Content-Disposition', `attachment; filename="${downloadName}"`);
    res.setHeader('Content-Type', c.fileType || 'application/octet-stream');
    res.setHeader('Content-Length', fs.statSync(c.filePath).size);

    // Stream the file
    const stream = fs.createReadStream(c.filePath);
    stream.on('error', (err) => {
      console.error('[Download] stream error:', err);
      if (!res.headersSent) res.status(500).json({ error: 'File read error' });
    });
    stream.pipe(res);
  } catch (e) {
    console.error('[Download] error:', e);
    res.status(500).json({ error: 'Server error during download' });
  }
});

/* ══════ GET view/:id ══════ */
router.get('/view/:id', auth, async (req, res) => {
  try {
    const c = await Certificate.findById(req.params.id);
    if (!c) return res.status(404).json({ error: 'Not found' });
    if (req.userRole === 'student' && c.student.toString() !== req.userId.toString()) return res.status(403).json({ error: 'Access denied' });
    if (!fs.existsSync(c.filePath)) return res.status(404).json({ error: 'File not found' });
    res.setHeader('Content-Type', c.fileType || 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="${c.fileName}"`);
    fs.createReadStream(c.filePath).pipe(res);
  } catch { res.status(500).json({ error: 'Server error' }); }
});

/* ══════ GET view-token/:id (for iframe) ══════ */
router.get('/view-token/:id', async (req, res) => {
  try {
    const jwt   = require('jsonwebtoken');
    const token = req.query.token;
    if (!token) return res.status(401).json({ error: 'No token' });
    try { jwt.verify(token, process.env.JWT_SECRET); } catch { return res.status(401).json({ error: 'Invalid token' }); }
    const c = await Certificate.findById(req.params.id);
    if (!c || !fs.existsSync(c.filePath)) return res.status(404).json({ error: 'Not found' });
    res.setHeader('Content-Type', c.fileType || 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="${c.fileName}"`);
    res.setHeader('Access-Control-Allow-Origin', '*');
    fs.createReadStream(c.filePath).pipe(res);
  } catch { res.status(500).json({ error: 'Server error' }); }
});

/* ══════ DELETE /:id ══════ */
router.delete('/:id', auth, async (req, res) => {
  try {
    const c = await Certificate.findById(req.params.id);
    if (!c) return res.status(404).json({ error: 'Not found' });
    if (req.userRole === 'student' && c.student.toString() !== req.userId.toString()) return res.status(403).json({ error: 'Access denied' });
    if (fs.existsSync(c.filePath)) fs.unlinkSync(c.filePath);
    await Certificate.findByIdAndDelete(req.params.id);
    res.json({ message: 'Deleted' });
  } catch { res.status(500).json({ error: 'Server error' }); }
});

/* ══════ PUT verify/:id (manual) ══════ */
router.put('/verify/:id', auth, teacherOrAdmin, async (req, res) => {
  try {
    const c = await Certificate.findById(req.params.id);
    if (!c) return res.status(404).json({ error: 'Not found' });
    const v = manualVerification(req.userId);
    Object.assign(c, {
      verificationStatus: v.status,
      verificationMethod: v.method,
      verifiedBy: req.userId,
      verifiedAt: v.verifiedAt,
      verifiedByRole: req.userRole || 'teacher',  // track who verified
    });
    await c.save();
    await c.populate('verifiedBy', 'name role');
    res.json({ message: 'Certificate verified successfully', certificate: c });
  } catch(e) { console.error('[Verify manual]', e); res.status(500).json({ error: 'Server error' }); }
});

/* ══════ GET stats/overview ══════ */
router.get('/stats/overview', auth, adminOnly, async (req, res) => {
  try {
    const total    = await Certificate.countDocuments();
    const verified = await Certificate.countDocuments({ verificationStatus:'verified' });
    const cats     = await Certificate.aggregate([{ $group:{ _id:'$category', count:{ $sum:1 } } }]);
    res.json({ totalCertificates:total, verifiedCertificates:verified, unverifiedCertificates:total-verified, categoryCounts:cats });
  } catch { res.status(500).json({ error: 'Server error' }); }
});

module.exports = router;
